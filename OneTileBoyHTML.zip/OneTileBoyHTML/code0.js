gdjs.MainCode = {};
gdjs.MainCode.forEachIndex2 = 0;

gdjs.MainCode.forEachIndex3 = 0;

gdjs.MainCode.forEachIndex4 = 0;

gdjs.MainCode.forEachObjects2 = [];

gdjs.MainCode.forEachObjects3 = [];

gdjs.MainCode.forEachObjects4 = [];

gdjs.MainCode.forEachTemporary2 = null;

gdjs.MainCode.forEachTemporary3 = null;

gdjs.MainCode.forEachTemporary4 = null;

gdjs.MainCode.forEachTotalCount2 = 0;

gdjs.MainCode.forEachTotalCount3 = 0;

gdjs.MainCode.forEachTotalCount4 = 0;

gdjs.MainCode.GDplayerObjects1= [];
gdjs.MainCode.GDplayerObjects2= [];
gdjs.MainCode.GDplayerObjects3= [];
gdjs.MainCode.GDplayerObjects4= [];
gdjs.MainCode.GDplayerObjects5= [];
gdjs.MainCode.GDGuide2Objects1= [];
gdjs.MainCode.GDGuide2Objects2= [];
gdjs.MainCode.GDGuide2Objects3= [];
gdjs.MainCode.GDGuide2Objects4= [];
gdjs.MainCode.GDGuide2Objects5= [];
gdjs.MainCode.GDGuide22Objects1= [];
gdjs.MainCode.GDGuide22Objects2= [];
gdjs.MainCode.GDGuide22Objects3= [];
gdjs.MainCode.GDGuide22Objects4= [];
gdjs.MainCode.GDGuide22Objects5= [];
gdjs.MainCode.GDGuide23Objects1= [];
gdjs.MainCode.GDGuide23Objects2= [];
gdjs.MainCode.GDGuide23Objects3= [];
gdjs.MainCode.GDGuide23Objects4= [];
gdjs.MainCode.GDGuide23Objects5= [];
gdjs.MainCode.GDTitleObjects1= [];
gdjs.MainCode.GDTitleObjects2= [];
gdjs.MainCode.GDTitleObjects3= [];
gdjs.MainCode.GDTitleObjects4= [];
gdjs.MainCode.GDTitleObjects5= [];
gdjs.MainCode.GDgrass1Objects1= [];
gdjs.MainCode.GDgrass1Objects2= [];
gdjs.MainCode.GDgrass1Objects3= [];
gdjs.MainCode.GDgrass1Objects4= [];
gdjs.MainCode.GDgrass1Objects5= [];
gdjs.MainCode.GDgrass2Objects1= [];
gdjs.MainCode.GDgrass2Objects2= [];
gdjs.MainCode.GDgrass2Objects3= [];
gdjs.MainCode.GDgrass2Objects4= [];
gdjs.MainCode.GDgrass2Objects5= [];
gdjs.MainCode.GDgrass3Objects1= [];
gdjs.MainCode.GDgrass3Objects2= [];
gdjs.MainCode.GDgrass3Objects3= [];
gdjs.MainCode.GDgrass3Objects4= [];
gdjs.MainCode.GDgrass3Objects5= [];
gdjs.MainCode.GDgrass4Objects1= [];
gdjs.MainCode.GDgrass4Objects2= [];
gdjs.MainCode.GDgrass4Objects3= [];
gdjs.MainCode.GDgrass4Objects4= [];
gdjs.MainCode.GDgrass4Objects5= [];
gdjs.MainCode.GDassetsObjects1= [];
gdjs.MainCode.GDassetsObjects2= [];
gdjs.MainCode.GDassetsObjects3= [];
gdjs.MainCode.GDassetsObjects4= [];
gdjs.MainCode.GDassetsObjects5= [];
gdjs.MainCode.GDmusicObjects1= [];
gdjs.MainCode.GDmusicObjects2= [];
gdjs.MainCode.GDmusicObjects3= [];
gdjs.MainCode.GDmusicObjects4= [];
gdjs.MainCode.GDmusicObjects5= [];
gdjs.MainCode.GDmusic2Objects1= [];
gdjs.MainCode.GDmusic2Objects2= [];
gdjs.MainCode.GDmusic2Objects3= [];
gdjs.MainCode.GDmusic2Objects4= [];
gdjs.MainCode.GDmusic2Objects5= [];
gdjs.MainCode.GDboneObjects1= [];
gdjs.MainCode.GDboneObjects2= [];
gdjs.MainCode.GDboneObjects3= [];
gdjs.MainCode.GDboneObjects4= [];
gdjs.MainCode.GDboneObjects5= [];
gdjs.MainCode.GDskullObjects1= [];
gdjs.MainCode.GDskullObjects2= [];
gdjs.MainCode.GDskullObjects3= [];
gdjs.MainCode.GDskullObjects4= [];
gdjs.MainCode.GDskullObjects5= [];
gdjs.MainCode.GDplayerhitboxObjects1= [];
gdjs.MainCode.GDplayerhitboxObjects2= [];
gdjs.MainCode.GDplayerhitboxObjects3= [];
gdjs.MainCode.GDplayerhitboxObjects4= [];
gdjs.MainCode.GDplayerhitboxObjects5= [];
gdjs.MainCode.GDenemyUPObjects1= [];
gdjs.MainCode.GDenemyUPObjects2= [];
gdjs.MainCode.GDenemyUPObjects3= [];
gdjs.MainCode.GDenemyUPObjects4= [];
gdjs.MainCode.GDenemyUPObjects5= [];
gdjs.MainCode.GDenemyDOWNObjects1= [];
gdjs.MainCode.GDenemyDOWNObjects2= [];
gdjs.MainCode.GDenemyDOWNObjects3= [];
gdjs.MainCode.GDenemyDOWNObjects4= [];
gdjs.MainCode.GDenemyDOWNObjects5= [];
gdjs.MainCode.GDenemyLEFTObjects1= [];
gdjs.MainCode.GDenemyLEFTObjects2= [];
gdjs.MainCode.GDenemyLEFTObjects3= [];
gdjs.MainCode.GDenemyLEFTObjects4= [];
gdjs.MainCode.GDenemyLEFTObjects5= [];
gdjs.MainCode.GDenemyRIGHTObjects1= [];
gdjs.MainCode.GDenemyRIGHTObjects2= [];
gdjs.MainCode.GDenemyRIGHTObjects3= [];
gdjs.MainCode.GDenemyRIGHTObjects4= [];
gdjs.MainCode.GDenemyRIGHTObjects5= [];
gdjs.MainCode.GDbulletObjects1= [];
gdjs.MainCode.GDbulletObjects2= [];
gdjs.MainCode.GDbulletObjects3= [];
gdjs.MainCode.GDbulletObjects4= [];
gdjs.MainCode.GDbulletObjects5= [];
gdjs.MainCode.GDmaintileObjects1= [];
gdjs.MainCode.GDmaintileObjects2= [];
gdjs.MainCode.GDmaintileObjects3= [];
gdjs.MainCode.GDmaintileObjects4= [];
gdjs.MainCode.GDmaintileObjects5= [];
gdjs.MainCode.GDtilesObjects1= [];
gdjs.MainCode.GDtilesObjects2= [];
gdjs.MainCode.GDtilesObjects3= [];
gdjs.MainCode.GDtilesObjects4= [];
gdjs.MainCode.GDtilesObjects5= [];
gdjs.MainCode.GDblockerObjects1= [];
gdjs.MainCode.GDblockerObjects2= [];
gdjs.MainCode.GDblockerObjects3= [];
gdjs.MainCode.GDblockerObjects4= [];
gdjs.MainCode.GDblockerObjects5= [];
gdjs.MainCode.GDdetectObjects1= [];
gdjs.MainCode.GDdetectObjects2= [];
gdjs.MainCode.GDdetectObjects3= [];
gdjs.MainCode.GDdetectObjects4= [];
gdjs.MainCode.GDdetectObjects5= [];
gdjs.MainCode.GDkillerorbObjects1= [];
gdjs.MainCode.GDkillerorbObjects2= [];
gdjs.MainCode.GDkillerorbObjects3= [];
gdjs.MainCode.GDkillerorbObjects4= [];
gdjs.MainCode.GDkillerorbObjects5= [];
gdjs.MainCode.GDbombtileObjects1= [];
gdjs.MainCode.GDbombtileObjects2= [];
gdjs.MainCode.GDbombtileObjects3= [];
gdjs.MainCode.GDbombtileObjects4= [];
gdjs.MainCode.GDbombtileObjects5= [];
gdjs.MainCode.GDblastObjects1= [];
gdjs.MainCode.GDblastObjects2= [];
gdjs.MainCode.GDblastObjects3= [];
gdjs.MainCode.GDblastObjects4= [];
gdjs.MainCode.GDblastObjects5= [];
gdjs.MainCode.GDhealthObjects1= [];
gdjs.MainCode.GDhealthObjects2= [];
gdjs.MainCode.GDhealthObjects3= [];
gdjs.MainCode.GDhealthObjects4= [];
gdjs.MainCode.GDhealthObjects5= [];
gdjs.MainCode.GDripObjects1= [];
gdjs.MainCode.GDripObjects2= [];
gdjs.MainCode.GDripObjects3= [];
gdjs.MainCode.GDripObjects4= [];
gdjs.MainCode.GDripObjects5= [];
gdjs.MainCode.GDkilledBulletObjects1= [];
gdjs.MainCode.GDkilledBulletObjects2= [];
gdjs.MainCode.GDkilledBulletObjects3= [];
gdjs.MainCode.GDkilledBulletObjects4= [];
gdjs.MainCode.GDkilledBulletObjects5= [];
gdjs.MainCode.GDtimeObjects1= [];
gdjs.MainCode.GDtimeObjects2= [];
gdjs.MainCode.GDtimeObjects3= [];
gdjs.MainCode.GDtimeObjects4= [];
gdjs.MainCode.GDtimeObjects5= [];
gdjs.MainCode.GDScoreObjects1= [];
gdjs.MainCode.GDScoreObjects2= [];
gdjs.MainCode.GDScoreObjects3= [];
gdjs.MainCode.GDScoreObjects4= [];
gdjs.MainCode.GDScoreObjects5= [];
gdjs.MainCode.GDrepelbulletObjects1= [];
gdjs.MainCode.GDrepelbulletObjects2= [];
gdjs.MainCode.GDrepelbulletObjects3= [];
gdjs.MainCode.GDrepelbulletObjects4= [];
gdjs.MainCode.GDrepelbulletObjects5= [];
gdjs.MainCode.GDpauseObjects1= [];
gdjs.MainCode.GDpauseObjects2= [];
gdjs.MainCode.GDpauseObjects3= [];
gdjs.MainCode.GDpauseObjects4= [];
gdjs.MainCode.GDpauseObjects5= [];
gdjs.MainCode.GDhomeObjects1= [];
gdjs.MainCode.GDhomeObjects2= [];
gdjs.MainCode.GDhomeObjects3= [];
gdjs.MainCode.GDhomeObjects4= [];
gdjs.MainCode.GDhomeObjects5= [];

gdjs.MainCode.conditionTrue_0 = {val:false};
gdjs.MainCode.condition0IsTrue_0 = {val:false};
gdjs.MainCode.condition1IsTrue_0 = {val:false};
gdjs.MainCode.condition2IsTrue_0 = {val:false};
gdjs.MainCode.condition3IsTrue_0 = {val:false};
gdjs.MainCode.conditionTrue_1 = {val:false};
gdjs.MainCode.condition0IsTrue_1 = {val:false};
gdjs.MainCode.condition1IsTrue_1 = {val:false};
gdjs.MainCode.condition2IsTrue_1 = {val:false};
gdjs.MainCode.condition3IsTrue_1 = {val:false};


gdjs.MainCode.asyncCallback11849948 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "..\\assets\\game music\\GameMusic.wav", 0, true, 0, 1);
}}
gdjs.MainCode.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.6), (runtimeScene) => (gdjs.MainCode.asyncCallback11849948(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDblockerObjects1Objects = Hashtable.newFrom({"blocker": gdjs.MainCode.GDblockerObjects1});
gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDripObjects4Objects = Hashtable.newFrom({"rip": gdjs.MainCode.GDripObjects4});
gdjs.MainCode.asyncCallback8860956 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("playerhitbox"), gdjs.MainCode.GDplayerhitboxObjects4);
gdjs.MainCode.GDripObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDripObjects4Objects, (( gdjs.MainCode.GDplayerhitboxObjects4.length === 0 ) ? 0 :gdjs.MainCode.GDplayerhitboxObjects4[0].getPointX("")), (( gdjs.MainCode.GDplayerhitboxObjects4.length === 0 ) ? 0 :gdjs.MainCode.GDplayerhitboxObjects4[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.MainCode.GDripObjects4.length ;i < len;++i) {
    gdjs.MainCode.GDripObjects4[i].setZOrder(6);
}
}{for(var i = 0, len = gdjs.MainCode.GDplayerhitboxObjects4.length ;i < len;++i) {
    gdjs.MainCode.GDplayerhitboxObjects4[i].deleteFromScene(runtimeScene);
}
}}
gdjs.MainCode.eventsList1 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.MainCode.asyncCallback8860956(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.asyncCallback9555372 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("player"), gdjs.MainCode.GDplayerObjects3);

{for(var i = 0, len = gdjs.MainCode.GDplayerObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDplayerObjects3[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.MainCode.eventsList1(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.MainCode.eventsList2 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.MainCode.GDplayerObjects2) asyncObjectsList.addObject("player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.MainCode.asyncCallback9555372(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList3 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("health"), gdjs.MainCode.GDhealthObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.MainCode.GDplayerObjects2);
{for(var i = 0, len = gdjs.MainCode.GDhealthObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDhealthObjects2[i].setWidth(48 / (gdjs.RuntimeObject.getVariableNumber(((gdjs.MainCode.GDplayerObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.MainCode.GDplayerObjects2[0].getVariables()).get("maxHealth"))) * (gdjs.RuntimeObject.getVariableNumber(((gdjs.MainCode.GDplayerObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.MainCode.GDplayerObjects2[0].getVariables()).get("Health"))));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.MainCode.GDplayerObjects2);

gdjs.MainCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDplayerObjects2.length;i<l;++i) {
    if ( gdjs.MainCode.GDplayerObjects2[i].getVariableNumber(gdjs.MainCode.GDplayerObjects2[i].getVariables().get("Health")) < 0 ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDplayerObjects2[k] = gdjs.MainCode.GDplayerObjects2[i];
        ++k;
    }
}
gdjs.MainCode.GDplayerObjects2.length = k;}if (gdjs.MainCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDplayerObjects2 */
{for(var i = 0, len = gdjs.MainCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDplayerObjects2[i].returnVariable(gdjs.MainCode.GDplayerObjects2[i].getVariables().get("Health")).setNumber(0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.MainCode.GDplayerObjects2);

gdjs.MainCode.condition0IsTrue_0.val = false;
gdjs.MainCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDplayerObjects2.length;i<l;++i) {
    if ( gdjs.MainCode.GDplayerObjects2[i].getVariableNumber(gdjs.MainCode.GDplayerObjects2[i].getVariables().get("Health")) == 0 ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDplayerObjects2[k] = gdjs.MainCode.GDplayerObjects2[i];
        ++k;
    }
}
gdjs.MainCode.GDplayerObjects2.length = k;}if ( gdjs.MainCode.condition0IsTrue_0.val ) {
{
{gdjs.MainCode.conditionTrue_1 = gdjs.MainCode.condition1IsTrue_0;
gdjs.MainCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11245828);
}
}}
if (gdjs.MainCode.condition1IsTrue_0.val) {

{ //Subevents
gdjs.MainCode.eventsList2(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.MainCode.GDplayerObjects2);

gdjs.MainCode.condition0IsTrue_0.val = false;
gdjs.MainCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDplayerObjects2.length;i<l;++i) {
    if ( gdjs.MainCode.GDplayerObjects2[i].getTimerElapsedTimeInSecondsOrNaN("regen") > 9 ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDplayerObjects2[k] = gdjs.MainCode.GDplayerObjects2[i];
        ++k;
    }
}
gdjs.MainCode.GDplayerObjects2.length = k;}if ( gdjs.MainCode.condition0IsTrue_0.val ) {
{
{gdjs.MainCode.conditionTrue_1 = gdjs.MainCode.condition1IsTrue_0;
gdjs.MainCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9363980);
}
}}
if (gdjs.MainCode.condition1IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDplayerObjects2 */
{for(var i = 0, len = gdjs.MainCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDplayerObjects2[i].returnVariable(gdjs.MainCode.GDplayerObjects2[i].getVariables().get("Health")).add(1);
}
}{for(var i = 0, len = gdjs.MainCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDplayerObjects2[i].resetTimer("regen");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.MainCode.GDplayerObjects1);

gdjs.MainCode.condition0IsTrue_0.val = false;
gdjs.MainCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDplayerObjects1.length;i<l;++i) {
    if ( gdjs.MainCode.GDplayerObjects1[i].getVariableNumber(gdjs.MainCode.GDplayerObjects1[i].getVariables().get("Health")) > 3 ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDplayerObjects1[k] = gdjs.MainCode.GDplayerObjects1[i];
        ++k;
    }
}
gdjs.MainCode.GDplayerObjects1.length = k;}if ( gdjs.MainCode.condition0IsTrue_0.val ) {
{
{gdjs.MainCode.conditionTrue_1 = gdjs.MainCode.condition1IsTrue_0;
gdjs.MainCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(8095804);
}
}}
if (gdjs.MainCode.condition1IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDplayerObjects1 */
{for(var i = 0, len = gdjs.MainCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDplayerObjects1[i].returnVariable(gdjs.MainCode.GDplayerObjects1[i].getVariables().get("Health")).setNumber(3);
}
}}

}


};gdjs.MainCode.asyncCallback8096780 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("player"), gdjs.MainCode.GDplayerObjects3);

gdjs.copyArray(asyncObjectsList.getObjects("playerhitbox"), gdjs.MainCode.GDplayerhitboxObjects3);

{for(var i = 0, len = gdjs.MainCode.GDplayerObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDplayerObjects3[i].getBehavior("Tween").addObjectPositionTween("pos", (( gdjs.MainCode.GDplayerhitboxObjects3.length === 0 ) ? 0 :gdjs.MainCode.GDplayerhitboxObjects3[0].getPointX("")), (( gdjs.MainCode.GDplayerhitboxObjects3.length === 0 ) ? 0 :gdjs.MainCode.GDplayerhitboxObjects3[0].getPointY("")), "easeFrom", 150, false);
}
}}
gdjs.MainCode.eventsList4 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.MainCode.GDplayerObjects2) asyncObjectsList.addObject("player", obj);
for (const obj of gdjs.MainCode.GDplayerhitboxObjects2) asyncObjectsList.addObject("playerhitbox", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.MainCode.asyncCallback8096780(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.asyncCallback8097676 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("player"), gdjs.MainCode.GDplayerObjects3);

gdjs.copyArray(asyncObjectsList.getObjects("playerhitbox"), gdjs.MainCode.GDplayerhitboxObjects3);

{for(var i = 0, len = gdjs.MainCode.GDplayerObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDplayerObjects3[i].getBehavior("Tween").addObjectPositionTween("pos", (( gdjs.MainCode.GDplayerhitboxObjects3.length === 0 ) ? 0 :gdjs.MainCode.GDplayerhitboxObjects3[0].getPointX("")), (( gdjs.MainCode.GDplayerhitboxObjects3.length === 0 ) ? 0 :gdjs.MainCode.GDplayerhitboxObjects3[0].getPointY("")), "easeFrom", 150, false);
}
}}
gdjs.MainCode.eventsList5 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.MainCode.GDplayerObjects2) asyncObjectsList.addObject("player", obj);
for (const obj of gdjs.MainCode.GDplayerhitboxObjects2) asyncObjectsList.addObject("playerhitbox", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.MainCode.asyncCallback8097676(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.asyncCallback8098596 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("player"), gdjs.MainCode.GDplayerObjects3);

gdjs.copyArray(asyncObjectsList.getObjects("playerhitbox"), gdjs.MainCode.GDplayerhitboxObjects3);

{for(var i = 0, len = gdjs.MainCode.GDplayerObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDplayerObjects3[i].getBehavior("Tween").addObjectPositionTween("pos", (( gdjs.MainCode.GDplayerhitboxObjects3.length === 0 ) ? 0 :gdjs.MainCode.GDplayerhitboxObjects3[0].getPointX("")), (( gdjs.MainCode.GDplayerhitboxObjects3.length === 0 ) ? 0 :gdjs.MainCode.GDplayerhitboxObjects3[0].getPointY("")), "easeFrom", 150, false);
}
}}
gdjs.MainCode.eventsList6 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.MainCode.GDplayerObjects2) asyncObjectsList.addObject("player", obj);
for (const obj of gdjs.MainCode.GDplayerhitboxObjects2) asyncObjectsList.addObject("playerhitbox", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.MainCode.asyncCallback8098596(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.asyncCallback8099468 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("player"), gdjs.MainCode.GDplayerObjects3);

gdjs.copyArray(asyncObjectsList.getObjects("playerhitbox"), gdjs.MainCode.GDplayerhitboxObjects3);

{for(var i = 0, len = gdjs.MainCode.GDplayerObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDplayerObjects3[i].getBehavior("Tween").addObjectPositionTween("pos", (( gdjs.MainCode.GDplayerhitboxObjects3.length === 0 ) ? 0 :gdjs.MainCode.GDplayerhitboxObjects3[0].getPointX("")), (( gdjs.MainCode.GDplayerhitboxObjects3.length === 0 ) ? 0 :gdjs.MainCode.GDplayerhitboxObjects3[0].getPointY("")), "easeFrom", 150, false);
}
}}
gdjs.MainCode.eventsList7 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.MainCode.GDplayerObjects2) asyncObjectsList.addObject("player", obj);
for (const obj of gdjs.MainCode.GDplayerhitboxObjects2) asyncObjectsList.addObject("playerhitbox", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.MainCode.asyncCallback8099468(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.MainCode.GDplayerObjects2});
gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDbulletObjects2Objects = Hashtable.newFrom({"bullet": gdjs.MainCode.GDbulletObjects2});
gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDbombtileObjects2Objects = Hashtable.newFrom({"bombtile": gdjs.MainCode.GDbombtileObjects2});
gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDplayerhitboxObjects2Objects = Hashtable.newFrom({"playerhitbox": gdjs.MainCode.GDplayerhitboxObjects2});
gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDbombtileObjects2Objects = Hashtable.newFrom({"bombtile": gdjs.MainCode.GDbombtileObjects2});
gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDplayerhitboxObjects1Objects = Hashtable.newFrom({"playerhitbox": gdjs.MainCode.GDplayerhitboxObjects1});
gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDbombtileObjects1Objects = Hashtable.newFrom({"bombtile": gdjs.MainCode.GDbombtileObjects1});
gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDblastObjects2Objects = Hashtable.newFrom({"blast": gdjs.MainCode.GDblastObjects2});
gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDblastObjects2Objects = Hashtable.newFrom({"blast": gdjs.MainCode.GDblastObjects2});
gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDblastObjects2Objects = Hashtable.newFrom({"blast": gdjs.MainCode.GDblastObjects2});
gdjs.MainCode.asyncCallback8103444 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("bombtile"), gdjs.MainCode.GDbombtileObjects2);

gdjs.copyArray(runtimeScene.getObjects("health"), gdjs.MainCode.GDhealthObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.MainCode.GDplayerObjects2);
gdjs.copyArray(asyncObjectsList.getObjects("playerhitbox"), gdjs.MainCode.GDplayerhitboxObjects2);

gdjs.MainCode.GDblastObjects2.length = 0;

{for(var i = 0, len = gdjs.MainCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDplayerObjects2[i].getBehavior("Flash").Flash(0.5, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "..\\assets\\Explosion35.wav", false, 150, 1);
}{for(var i = 0, len = gdjs.MainCode.GDbombtileObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDbombtileObjects2[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 2, 0.1, 0.3, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDblastObjects2Objects, (( gdjs.MainCode.GDplayerhitboxObjects2.length === 0 ) ? 0 :gdjs.MainCode.GDplayerhitboxObjects2[0].getPointX("center")), (( gdjs.MainCode.GDplayerhitboxObjects2.length === 0 ) ? 0 :gdjs.MainCode.GDplayerhitboxObjects2[0].getPointY("center")), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDblastObjects2Objects, (( gdjs.MainCode.GDplayerhitboxObjects2.length === 0 ) ? 0 :gdjs.MainCode.GDplayerhitboxObjects2[0].getPointX("center")), (( gdjs.MainCode.GDplayerhitboxObjects2.length === 0 ) ? 0 :gdjs.MainCode.GDplayerhitboxObjects2[0].getPointY("center")), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDblastObjects2Objects, (( gdjs.MainCode.GDplayerhitboxObjects2.length === 0 ) ? 0 :gdjs.MainCode.GDplayerhitboxObjects2[0].getPointX("center")), (( gdjs.MainCode.GDplayerhitboxObjects2.length === 0 ) ? 0 :gdjs.MainCode.GDplayerhitboxObjects2[0].getPointY("center")), "");
}{for(var i = 0, len = gdjs.MainCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDplayerObjects2[i].returnVariable(gdjs.MainCode.GDplayerObjects2[i].getVariables().get("Health")).sub(2);
}
}{for(var i = 0, len = gdjs.MainCode.GDhealthObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDhealthObjects2[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(2, 0, 1, 12, 0.08, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "hurt.wav", false, 100, 1);
}}
gdjs.MainCode.eventsList8 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.MainCode.GDbombtileObjects1) asyncObjectsList.addObject("bombtile", obj);
for (const obj of gdjs.MainCode.GDplayerhitboxObjects1) asyncObjectsList.addObject("playerhitbox", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.MainCode.asyncCallback8103444(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList9 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.MainCode.GDplayerObjects2);

gdjs.MainCode.condition0IsTrue_0.val = false;
gdjs.MainCode.condition1IsTrue_0.val = false;
gdjs.MainCode.condition2IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "w");
}if ( gdjs.MainCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDplayerObjects2.length;i<l;++i) {
    if ( gdjs.MainCode.GDplayerObjects2[i].getTimerElapsedTimeInSecondsOrNaN("coolD") > 0.3 ) {
        gdjs.MainCode.condition1IsTrue_0.val = true;
        gdjs.MainCode.GDplayerObjects2[k] = gdjs.MainCode.GDplayerObjects2[i];
        ++k;
    }
}
gdjs.MainCode.GDplayerObjects2.length = k;}if ( gdjs.MainCode.condition1IsTrue_0.val ) {
{
{gdjs.MainCode.conditionTrue_1 = gdjs.MainCode.condition2IsTrue_0;
gdjs.MainCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(8096428);
}
}}
}
if (gdjs.MainCode.condition2IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDplayerObjects2 */
gdjs.copyArray(runtimeScene.getObjects("playerhitbox"), gdjs.MainCode.GDplayerhitboxObjects2);
{for(var i = 0, len = gdjs.MainCode.GDplayerhitboxObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDplayerhitboxObjects2[i].setY((gdjs.MainCode.GDplayerhitboxObjects2[i].getPointY("")) - 16);
}
}{for(var i = 0, len = gdjs.MainCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDplayerObjects2[i].resetTimer("coolD");
}
}
{ //Subevents
gdjs.MainCode.eventsList4(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.MainCode.GDplayerObjects2);

gdjs.MainCode.condition0IsTrue_0.val = false;
gdjs.MainCode.condition1IsTrue_0.val = false;
gdjs.MainCode.condition2IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "s");
}if ( gdjs.MainCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDplayerObjects2.length;i<l;++i) {
    if ( gdjs.MainCode.GDplayerObjects2[i].getTimerElapsedTimeInSecondsOrNaN("coolD") > 0.3 ) {
        gdjs.MainCode.condition1IsTrue_0.val = true;
        gdjs.MainCode.GDplayerObjects2[k] = gdjs.MainCode.GDplayerObjects2[i];
        ++k;
    }
}
gdjs.MainCode.GDplayerObjects2.length = k;}if ( gdjs.MainCode.condition1IsTrue_0.val ) {
{
{gdjs.MainCode.conditionTrue_1 = gdjs.MainCode.condition2IsTrue_0;
gdjs.MainCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(8097300);
}
}}
}
if (gdjs.MainCode.condition2IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDplayerObjects2 */
gdjs.copyArray(runtimeScene.getObjects("playerhitbox"), gdjs.MainCode.GDplayerhitboxObjects2);
{for(var i = 0, len = gdjs.MainCode.GDplayerhitboxObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDplayerhitboxObjects2[i].setY((gdjs.MainCode.GDplayerhitboxObjects2[i].getPointY("")) + 16);
}
}{for(var i = 0, len = gdjs.MainCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDplayerObjects2[i].resetTimer("coolD");
}
}
{ //Subevents
gdjs.MainCode.eventsList5(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.MainCode.GDplayerObjects2);

gdjs.MainCode.condition0IsTrue_0.val = false;
gdjs.MainCode.condition1IsTrue_0.val = false;
gdjs.MainCode.condition2IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}if ( gdjs.MainCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDplayerObjects2.length;i<l;++i) {
    if ( gdjs.MainCode.GDplayerObjects2[i].getTimerElapsedTimeInSecondsOrNaN("coolD") > 0.3 ) {
        gdjs.MainCode.condition1IsTrue_0.val = true;
        gdjs.MainCode.GDplayerObjects2[k] = gdjs.MainCode.GDplayerObjects2[i];
        ++k;
    }
}
gdjs.MainCode.GDplayerObjects2.length = k;}if ( gdjs.MainCode.condition1IsTrue_0.val ) {
{
{gdjs.MainCode.conditionTrue_1 = gdjs.MainCode.condition2IsTrue_0;
gdjs.MainCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(8098220);
}
}}
}
if (gdjs.MainCode.condition2IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDplayerObjects2 */
gdjs.copyArray(runtimeScene.getObjects("playerhitbox"), gdjs.MainCode.GDplayerhitboxObjects2);
{for(var i = 0, len = gdjs.MainCode.GDplayerhitboxObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDplayerhitboxObjects2[i].setX((gdjs.MainCode.GDplayerhitboxObjects2[i].getPointX("")) - 16);
}
}{for(var i = 0, len = gdjs.MainCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDplayerObjects2[i].resetTimer("coolD");
}
}
{ //Subevents
gdjs.MainCode.eventsList6(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.MainCode.GDplayerObjects2);

gdjs.MainCode.condition0IsTrue_0.val = false;
gdjs.MainCode.condition1IsTrue_0.val = false;
gdjs.MainCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDplayerObjects2.length;i<l;++i) {
    if ( gdjs.MainCode.GDplayerObjects2[i].getTimerElapsedTimeInSecondsOrNaN("coolD") > 0.3 ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDplayerObjects2[k] = gdjs.MainCode.GDplayerObjects2[i];
        ++k;
    }
}
gdjs.MainCode.GDplayerObjects2.length = k;}if ( gdjs.MainCode.condition0IsTrue_0.val ) {
{
gdjs.MainCode.condition1IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
}if ( gdjs.MainCode.condition1IsTrue_0.val ) {
{
{gdjs.MainCode.conditionTrue_1 = gdjs.MainCode.condition2IsTrue_0;
gdjs.MainCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(8099116);
}
}}
}
if (gdjs.MainCode.condition2IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDplayerObjects2 */
gdjs.copyArray(runtimeScene.getObjects("playerhitbox"), gdjs.MainCode.GDplayerhitboxObjects2);
{for(var i = 0, len = gdjs.MainCode.GDplayerhitboxObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDplayerhitboxObjects2[i].setX((gdjs.MainCode.GDplayerhitboxObjects2[i].getPointX("")) + 16);
}
}{for(var i = 0, len = gdjs.MainCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDplayerObjects2[i].resetTimer("coolD");
}
}
{ //Subevents
gdjs.MainCode.eventsList7(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("bullet"), gdjs.MainCode.GDbulletObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.MainCode.GDplayerObjects2);

gdjs.MainCode.condition0IsTrue_0.val = false;
gdjs.MainCode.condition1IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDplayerObjects2Objects, gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDbulletObjects2Objects, false, runtimeScene, false);
}if ( gdjs.MainCode.condition0IsTrue_0.val ) {
{
{gdjs.MainCode.conditionTrue_1 = gdjs.MainCode.condition1IsTrue_0;
gdjs.MainCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(8099972);
}
}}
if (gdjs.MainCode.condition1IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDbulletObjects2 */
/* Reuse gdjs.MainCode.GDplayerObjects2 */
{for(var i = 0, len = gdjs.MainCode.GDbulletObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDbulletObjects2[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "hurt.wav", false, 60, 1);
}{for(var i = 0, len = gdjs.MainCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDplayerObjects2[i].getBehavior("Flash").Flash(0.6, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 0.4, 0.1, 0.1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{for(var i = 0, len = gdjs.MainCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDplayerObjects2[i].returnVariable(gdjs.MainCode.GDplayerObjects2[i].getVariables().get("Health")).sub(0.5);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.MainCode.GDplayerObjects2);

gdjs.MainCode.condition0IsTrue_0.val = false;
gdjs.MainCode.condition1IsTrue_0.val = false;
gdjs.MainCode.condition2IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "idledetect") > 8;
}if ( gdjs.MainCode.condition0IsTrue_0.val ) {
{
{gdjs.MainCode.conditionTrue_1 = gdjs.MainCode.condition1IsTrue_0;
gdjs.MainCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(8101300);
}
}if ( gdjs.MainCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDplayerObjects2.length;i<l;++i) {
    if ( gdjs.MainCode.GDplayerObjects2[i].getVariableNumber(gdjs.MainCode.GDplayerObjects2[i].getVariables().get("Health")) != 0 ) {
        gdjs.MainCode.condition2IsTrue_0.val = true;
        gdjs.MainCode.GDplayerObjects2[k] = gdjs.MainCode.GDplayerObjects2[i];
        ++k;
    }
}
gdjs.MainCode.GDplayerObjects2.length = k;}}
}
if (gdjs.MainCode.condition2IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("playerhitbox"), gdjs.MainCode.GDplayerhitboxObjects2);
gdjs.MainCode.GDbombtileObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDbombtileObjects2Objects, (( gdjs.MainCode.GDplayerhitboxObjects2.length === 0 ) ? 0 :gdjs.MainCode.GDplayerhitboxObjects2[0].getPointX("")), (( gdjs.MainCode.GDplayerhitboxObjects2.length === 0 ) ? 0 :gdjs.MainCode.GDplayerhitboxObjects2[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.MainCode.GDbombtileObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDbombtileObjects2[i].setZOrder(2);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Alert.wav", false, 150, 1);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "idledetect");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("bombtile"), gdjs.MainCode.GDbombtileObjects2);
gdjs.copyArray(runtimeScene.getObjects("playerhitbox"), gdjs.MainCode.GDplayerhitboxObjects2);

gdjs.MainCode.condition0IsTrue_0.val = false;
gdjs.MainCode.condition1IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDplayerhitboxObjects2Objects, gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDbombtileObjects2Objects, false, runtimeScene, false);
}if ( gdjs.MainCode.condition0IsTrue_0.val ) {
{
{gdjs.MainCode.conditionTrue_1 = gdjs.MainCode.condition1IsTrue_0;
gdjs.MainCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(8102532);
}
}}
if (gdjs.MainCode.condition1IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDbombtileObjects2 */
{for(var i = 0, len = gdjs.MainCode.GDbombtileObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDbombtileObjects2[i].returnVariable(gdjs.MainCode.GDbombtileObjects2[i].getVariables().get("trigger")).add(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("bombtile"), gdjs.MainCode.GDbombtileObjects1);
gdjs.copyArray(runtimeScene.getObjects("playerhitbox"), gdjs.MainCode.GDplayerhitboxObjects1);

gdjs.MainCode.condition0IsTrue_0.val = false;
gdjs.MainCode.condition1IsTrue_0.val = false;
gdjs.MainCode.condition2IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDplayerhitboxObjects1Objects, gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDbombtileObjects1Objects, false, runtimeScene, false);
}if ( gdjs.MainCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDbombtileObjects1.length;i<l;++i) {
    if ( gdjs.MainCode.GDbombtileObjects1[i].getVariableNumber(gdjs.MainCode.GDbombtileObjects1[i].getVariables().get("trigger")) > 1 ) {
        gdjs.MainCode.condition1IsTrue_0.val = true;
        gdjs.MainCode.GDbombtileObjects1[k] = gdjs.MainCode.GDbombtileObjects1[i];
        ++k;
    }
}
gdjs.MainCode.GDbombtileObjects1.length = k;}if ( gdjs.MainCode.condition1IsTrue_0.val ) {
{
{gdjs.MainCode.conditionTrue_1 = gdjs.MainCode.condition2IsTrue_0;
gdjs.MainCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(8103372);
}
}}
}
if (gdjs.MainCode.condition2IsTrue_0.val) {

{ //Subevents
gdjs.MainCode.eventsList8(runtimeScene);} //End of subevents
}

}


};gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDenemyRIGHTObjects2Objects = Hashtable.newFrom({"enemyRIGHT": gdjs.MainCode.GDenemyRIGHTObjects2});
gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDdetectObjects2Objects = Hashtable.newFrom({"detect": gdjs.MainCode.GDdetectObjects2});
gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDenemyLEFTObjects2Objects = Hashtable.newFrom({"enemyLEFT": gdjs.MainCode.GDenemyLEFTObjects2});
gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDdetectObjects2Objects = Hashtable.newFrom({"detect": gdjs.MainCode.GDdetectObjects2});
gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDenemyDOWNObjects2Objects = Hashtable.newFrom({"enemyDOWN": gdjs.MainCode.GDenemyDOWNObjects2});
gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDdetectObjects2Objects = Hashtable.newFrom({"detect": gdjs.MainCode.GDdetectObjects2});
gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDenemyUPObjects2Objects = Hashtable.newFrom({"enemyUP": gdjs.MainCode.GDenemyUPObjects2});
gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDdetectObjects2Objects = Hashtable.newFrom({"detect": gdjs.MainCode.GDdetectObjects2});
gdjs.MainCode.eventsList10 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("detect"), gdjs.MainCode.GDdetectObjects2);
gdjs.copyArray(runtimeScene.getObjects("enemyRIGHT"), gdjs.MainCode.GDenemyRIGHTObjects2);

gdjs.MainCode.condition0IsTrue_0.val = false;
gdjs.MainCode.condition1IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDenemyRIGHTObjects2Objects, gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDdetectObjects2Objects, false, runtimeScene, false);
}if ( gdjs.MainCode.condition0IsTrue_0.val ) {
{
{gdjs.MainCode.conditionTrue_1 = gdjs.MainCode.condition1IsTrue_0;
gdjs.MainCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(8105420);
}
}}
if (gdjs.MainCode.condition1IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDenemyRIGHTObjects2 */
{for(var i = 0, len = gdjs.MainCode.GDenemyRIGHTObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDenemyRIGHTObjects2[i].toggleVariableBoolean(gdjs.MainCode.GDenemyRIGHTObjects2[i].getVariables().get("side"));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("detect"), gdjs.MainCode.GDdetectObjects2);
gdjs.copyArray(runtimeScene.getObjects("enemyLEFT"), gdjs.MainCode.GDenemyLEFTObjects2);

gdjs.MainCode.condition0IsTrue_0.val = false;
gdjs.MainCode.condition1IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDenemyLEFTObjects2Objects, gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDdetectObjects2Objects, false, runtimeScene, false);
}if ( gdjs.MainCode.condition0IsTrue_0.val ) {
{
{gdjs.MainCode.conditionTrue_1 = gdjs.MainCode.condition1IsTrue_0;
gdjs.MainCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(8106020);
}
}}
if (gdjs.MainCode.condition1IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDenemyLEFTObjects2 */
{for(var i = 0, len = gdjs.MainCode.GDenemyLEFTObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDenemyLEFTObjects2[i].toggleVariableBoolean(gdjs.MainCode.GDenemyLEFTObjects2[i].getVariables().get("side"));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("detect"), gdjs.MainCode.GDdetectObjects2);
gdjs.copyArray(runtimeScene.getObjects("enemyDOWN"), gdjs.MainCode.GDenemyDOWNObjects2);

gdjs.MainCode.condition0IsTrue_0.val = false;
gdjs.MainCode.condition1IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDenemyDOWNObjects2Objects, gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDdetectObjects2Objects, false, runtimeScene, false);
}if ( gdjs.MainCode.condition0IsTrue_0.val ) {
{
{gdjs.MainCode.conditionTrue_1 = gdjs.MainCode.condition1IsTrue_0;
gdjs.MainCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(8106644);
}
}}
if (gdjs.MainCode.condition1IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDenemyDOWNObjects2 */
{for(var i = 0, len = gdjs.MainCode.GDenemyDOWNObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDenemyDOWNObjects2[i].toggleVariableBoolean(gdjs.MainCode.GDenemyDOWNObjects2[i].getVariables().get("side"));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("detect"), gdjs.MainCode.GDdetectObjects2);
gdjs.copyArray(runtimeScene.getObjects("enemyUP"), gdjs.MainCode.GDenemyUPObjects2);

gdjs.MainCode.condition0IsTrue_0.val = false;
gdjs.MainCode.condition1IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDenemyUPObjects2Objects, gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDdetectObjects2Objects, false, runtimeScene, false);
}if ( gdjs.MainCode.condition0IsTrue_0.val ) {
{
{gdjs.MainCode.conditionTrue_1 = gdjs.MainCode.condition1IsTrue_0;
gdjs.MainCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(8107220);
}
}}
if (gdjs.MainCode.condition1IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDenemyUPObjects2 */
{for(var i = 0, len = gdjs.MainCode.GDenemyUPObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDenemyUPObjects2[i].toggleVariableBoolean(gdjs.MainCode.GDenemyUPObjects2[i].getVariables().get("side"));
}
}}

}


{


gdjs.MainCode.condition0IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.MainCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("enemyDOWN"), gdjs.MainCode.GDenemyDOWNObjects1);
gdjs.copyArray(runtimeScene.getObjects("enemyLEFT"), gdjs.MainCode.GDenemyLEFTObjects1);
gdjs.copyArray(runtimeScene.getObjects("enemyRIGHT"), gdjs.MainCode.GDenemyRIGHTObjects1);
gdjs.copyArray(runtimeScene.getObjects("enemyUP"), gdjs.MainCode.GDenemyUPObjects1);
{for(var i = 0, len = gdjs.MainCode.GDenemyUPObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDenemyUPObjects1[i].toggleVariableBoolean(gdjs.MainCode.GDenemyUPObjects1[i].getVariables().get("side"));
}
}{for(var i = 0, len = gdjs.MainCode.GDenemyDOWNObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDenemyDOWNObjects1[i].toggleVariableBoolean(gdjs.MainCode.GDenemyDOWNObjects1[i].getVariables().get("side"));
}
}{for(var i = 0, len = gdjs.MainCode.GDenemyLEFTObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDenemyLEFTObjects1[i].toggleVariableBoolean(gdjs.MainCode.GDenemyLEFTObjects1[i].getVariables().get("side"));
}
}{for(var i = 0, len = gdjs.MainCode.GDenemyRIGHTObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDenemyRIGHTObjects1[i].toggleVariableBoolean(gdjs.MainCode.GDenemyRIGHTObjects1[i].getVariables().get("side"));
}
}}

}


};gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDbulletObjects4Objects = Hashtable.newFrom({"bullet": gdjs.MainCode.GDbulletObjects4});
gdjs.MainCode.eventsList11 = function(runtimeScene) {

};gdjs.MainCode.eventsList12 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("enemyRIGHT"), gdjs.MainCode.GDenemyRIGHTObjects3);

for(gdjs.MainCode.forEachIndex4 = 0;gdjs.MainCode.forEachIndex4 < gdjs.MainCode.GDenemyRIGHTObjects3.length;++gdjs.MainCode.forEachIndex4) {
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.MainCode.GDplayerObjects4);
gdjs.MainCode.GDbulletObjects4.length = 0;

gdjs.MainCode.GDenemyRIGHTObjects4.length = 0;


gdjs.MainCode.forEachTemporary4 = gdjs.MainCode.GDenemyRIGHTObjects3[gdjs.MainCode.forEachIndex4];
gdjs.MainCode.GDenemyRIGHTObjects4.push(gdjs.MainCode.forEachTemporary4);
gdjs.MainCode.condition0IsTrue_0.val = false;
gdjs.MainCode.condition1IsTrue_0.val = false;
gdjs.MainCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDenemyRIGHTObjects4.length;i<l;++i) {
    if ( gdjs.MainCode.GDenemyRIGHTObjects4[i].getTimerElapsedTimeInSecondsOrNaN("shoot") > 2.3 ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDenemyRIGHTObjects4[k] = gdjs.MainCode.GDenemyRIGHTObjects4[i];
        ++k;
    }
}
gdjs.MainCode.GDenemyRIGHTObjects4.length = k;}if ( gdjs.MainCode.condition0IsTrue_0.val ) {
{
{gdjs.MainCode.conditionTrue_1 = gdjs.MainCode.condition1IsTrue_0;
gdjs.MainCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(8108708);
}
}if ( gdjs.MainCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDplayerObjects4.length;i<l;++i) {
    if ( gdjs.MainCode.GDplayerObjects4[i].getVariableNumber(gdjs.MainCode.GDplayerObjects4[i].getVariables().get("Health")) != 0 ) {
        gdjs.MainCode.condition2IsTrue_0.val = true;
        gdjs.MainCode.GDplayerObjects4[k] = gdjs.MainCode.GDplayerObjects4[i];
        ++k;
    }
}
gdjs.MainCode.GDplayerObjects4.length = k;}}
}
if (gdjs.MainCode.condition2IsTrue_0.val) {
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDbulletObjects4Objects, (( gdjs.MainCode.GDenemyRIGHTObjects4.length === 0 ) ? 0 :gdjs.MainCode.GDenemyRIGHTObjects4[0].getPointX("")), Math.ceil((( gdjs.MainCode.GDenemyRIGHTObjects4.length === 0 ) ? 0 :gdjs.MainCode.GDenemyRIGHTObjects4[0].getPointY(""))), "");
}{for(var i = 0, len = gdjs.MainCode.GDbulletObjects4.length ;i < len;++i) {
    gdjs.MainCode.GDbulletObjects4[i].addForce(-(80), 0, 1);
}
}{for(var i = 0, len = gdjs.MainCode.GDbulletObjects4.length ;i < len;++i) {
    gdjs.MainCode.GDbulletObjects4[i].rotateTowardAngle(90, 0, runtimeScene);
}
}{for(var i = 0, len = gdjs.MainCode.GDenemyRIGHTObjects4.length ;i < len;++i) {
    gdjs.MainCode.GDenemyRIGHTObjects4[i].resetTimer("shoot");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "shoot.wav", false, 100, 1);
}}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("enemyRIGHT"), gdjs.MainCode.GDenemyRIGHTObjects3);

gdjs.MainCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDenemyRIGHTObjects3.length;i<l;++i) {
    if ( gdjs.MainCode.GDenemyRIGHTObjects3[i].getVariableBoolean(gdjs.MainCode.GDenemyRIGHTObjects3[i].getVariables().get("side"), true) ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDenemyRIGHTObjects3[k] = gdjs.MainCode.GDenemyRIGHTObjects3[i];
        ++k;
    }
}
gdjs.MainCode.GDenemyRIGHTObjects3.length = k;}if (gdjs.MainCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDenemyRIGHTObjects3 */
{for(var i = 0, len = gdjs.MainCode.GDenemyRIGHTObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDenemyRIGHTObjects3[i].getBehavior("TopDownMovement").simulateUpKey();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("enemyRIGHT"), gdjs.MainCode.GDenemyRIGHTObjects2);

gdjs.MainCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDenemyRIGHTObjects2.length;i<l;++i) {
    if ( gdjs.MainCode.GDenemyRIGHTObjects2[i].getVariableBoolean(gdjs.MainCode.GDenemyRIGHTObjects2[i].getVariables().get("side"), false) ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDenemyRIGHTObjects2[k] = gdjs.MainCode.GDenemyRIGHTObjects2[i];
        ++k;
    }
}
gdjs.MainCode.GDenemyRIGHTObjects2.length = k;}if (gdjs.MainCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDenemyRIGHTObjects2 */
{for(var i = 0, len = gdjs.MainCode.GDenemyRIGHTObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDenemyRIGHTObjects2[i].getBehavior("TopDownMovement").simulateDownKey();
}
}}

}


};gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDbulletObjects4Objects = Hashtable.newFrom({"bullet": gdjs.MainCode.GDbulletObjects4});
gdjs.MainCode.eventsList13 = function(runtimeScene) {

};gdjs.MainCode.eventsList14 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("enemyUP"), gdjs.MainCode.GDenemyUPObjects3);

gdjs.MainCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDenemyUPObjects3.length;i<l;++i) {
    if ( gdjs.MainCode.GDenemyUPObjects3[i].getVariableBoolean(gdjs.MainCode.GDenemyUPObjects3[i].getVariables().get("side"), false) ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDenemyUPObjects3[k] = gdjs.MainCode.GDenemyUPObjects3[i];
        ++k;
    }
}
gdjs.MainCode.GDenemyUPObjects3.length = k;}if (gdjs.MainCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDenemyUPObjects3 */
{for(var i = 0, len = gdjs.MainCode.GDenemyUPObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDenemyUPObjects3[i].getBehavior("PlatformerObject").simulateControl("Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("enemyUP"), gdjs.MainCode.GDenemyUPObjects3);

gdjs.MainCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDenemyUPObjects3.length;i<l;++i) {
    if ( gdjs.MainCode.GDenemyUPObjects3[i].getVariableBoolean(gdjs.MainCode.GDenemyUPObjects3[i].getVariables().get("side"), true) ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDenemyUPObjects3[k] = gdjs.MainCode.GDenemyUPObjects3[i];
        ++k;
    }
}
gdjs.MainCode.GDenemyUPObjects3.length = k;}if (gdjs.MainCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDenemyUPObjects3 */
{for(var i = 0, len = gdjs.MainCode.GDenemyUPObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDenemyUPObjects3[i].getBehavior("PlatformerObject").simulateControl("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("enemyUP"), gdjs.MainCode.GDenemyUPObjects3);

for(gdjs.MainCode.forEachIndex4 = 0;gdjs.MainCode.forEachIndex4 < gdjs.MainCode.GDenemyUPObjects3.length;++gdjs.MainCode.forEachIndex4) {
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.MainCode.GDplayerObjects4);
gdjs.MainCode.GDbulletObjects4.length = 0;

gdjs.MainCode.GDenemyUPObjects4.length = 0;


gdjs.MainCode.forEachTemporary4 = gdjs.MainCode.GDenemyUPObjects3[gdjs.MainCode.forEachIndex4];
gdjs.MainCode.GDenemyUPObjects4.push(gdjs.MainCode.forEachTemporary4);
gdjs.MainCode.condition0IsTrue_0.val = false;
gdjs.MainCode.condition1IsTrue_0.val = false;
gdjs.MainCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDenemyUPObjects4.length;i<l;++i) {
    if ( gdjs.MainCode.GDenemyUPObjects4[i].getTimerElapsedTimeInSecondsOrNaN("shoot") > 1.5 ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDenemyUPObjects4[k] = gdjs.MainCode.GDenemyUPObjects4[i];
        ++k;
    }
}
gdjs.MainCode.GDenemyUPObjects4.length = k;}if ( gdjs.MainCode.condition0IsTrue_0.val ) {
{
{gdjs.MainCode.conditionTrue_1 = gdjs.MainCode.condition1IsTrue_0;
gdjs.MainCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(8112668);
}
}if ( gdjs.MainCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDplayerObjects4.length;i<l;++i) {
    if ( gdjs.MainCode.GDplayerObjects4[i].getVariableNumber(gdjs.MainCode.GDplayerObjects4[i].getVariables().get("Health")) != 0 ) {
        gdjs.MainCode.condition2IsTrue_0.val = true;
        gdjs.MainCode.GDplayerObjects4[k] = gdjs.MainCode.GDplayerObjects4[i];
        ++k;
    }
}
gdjs.MainCode.GDplayerObjects4.length = k;}}
}
if (gdjs.MainCode.condition2IsTrue_0.val) {
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDbulletObjects4Objects, Math.ceil((( gdjs.MainCode.GDenemyUPObjects4.length === 0 ) ? 0 :gdjs.MainCode.GDenemyUPObjects4[0].getPointX(""))), (( gdjs.MainCode.GDenemyUPObjects4.length === 0 ) ? 0 :gdjs.MainCode.GDenemyUPObjects4[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.MainCode.GDbulletObjects4.length ;i < len;++i) {
    gdjs.MainCode.GDbulletObjects4[i].addForce(0, 80, 1);
}
}{for(var i = 0, len = gdjs.MainCode.GDenemyUPObjects4.length ;i < len;++i) {
    gdjs.MainCode.GDenemyUPObjects4[i].resetTimer("shoot");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "shoot.wav", false, 100, 1);
}}
}

}


{


{
}

}


};gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDbulletObjects3Objects = Hashtable.newFrom({"bullet": gdjs.MainCode.GDbulletObjects3});
gdjs.MainCode.eventsList15 = function(runtimeScene) {

};gdjs.MainCode.eventsList16 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("enemyDOWN"), gdjs.MainCode.GDenemyDOWNObjects3);

gdjs.MainCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDenemyDOWNObjects3.length;i<l;++i) {
    if ( gdjs.MainCode.GDenemyDOWNObjects3[i].getVariableBoolean(gdjs.MainCode.GDenemyDOWNObjects3[i].getVariables().get("side"), false) ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDenemyDOWNObjects3[k] = gdjs.MainCode.GDenemyDOWNObjects3[i];
        ++k;
    }
}
gdjs.MainCode.GDenemyDOWNObjects3.length = k;}if (gdjs.MainCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDenemyDOWNObjects3 */
{for(var i = 0, len = gdjs.MainCode.GDenemyDOWNObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDenemyDOWNObjects3[i].getBehavior("PlatformerObject").simulateControl("Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("enemyDOWN"), gdjs.MainCode.GDenemyDOWNObjects3);

gdjs.MainCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDenemyDOWNObjects3.length;i<l;++i) {
    if ( gdjs.MainCode.GDenemyDOWNObjects3[i].getVariableBoolean(gdjs.MainCode.GDenemyDOWNObjects3[i].getVariables().get("side"), true) ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDenemyDOWNObjects3[k] = gdjs.MainCode.GDenemyDOWNObjects3[i];
        ++k;
    }
}
gdjs.MainCode.GDenemyDOWNObjects3.length = k;}if (gdjs.MainCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDenemyDOWNObjects3 */
{for(var i = 0, len = gdjs.MainCode.GDenemyDOWNObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDenemyDOWNObjects3[i].getBehavior("PlatformerObject").simulateControl("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("enemyDOWN"), gdjs.MainCode.GDenemyDOWNObjects2);

for(gdjs.MainCode.forEachIndex3 = 0;gdjs.MainCode.forEachIndex3 < gdjs.MainCode.GDenemyDOWNObjects2.length;++gdjs.MainCode.forEachIndex3) {
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.MainCode.GDplayerObjects3);
gdjs.MainCode.GDbulletObjects3.length = 0;

gdjs.MainCode.GDenemyDOWNObjects3.length = 0;


gdjs.MainCode.forEachTemporary3 = gdjs.MainCode.GDenemyDOWNObjects2[gdjs.MainCode.forEachIndex3];
gdjs.MainCode.GDenemyDOWNObjects3.push(gdjs.MainCode.forEachTemporary3);
gdjs.MainCode.condition0IsTrue_0.val = false;
gdjs.MainCode.condition1IsTrue_0.val = false;
gdjs.MainCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDenemyDOWNObjects3.length;i<l;++i) {
    if ( gdjs.MainCode.GDenemyDOWNObjects3[i].getTimerElapsedTimeInSecondsOrNaN("shoot") > 2 ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDenemyDOWNObjects3[k] = gdjs.MainCode.GDenemyDOWNObjects3[i];
        ++k;
    }
}
gdjs.MainCode.GDenemyDOWNObjects3.length = k;}if ( gdjs.MainCode.condition0IsTrue_0.val ) {
{
{gdjs.MainCode.conditionTrue_1 = gdjs.MainCode.condition1IsTrue_0;
gdjs.MainCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(8115180);
}
}if ( gdjs.MainCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDplayerObjects3.length;i<l;++i) {
    if ( gdjs.MainCode.GDplayerObjects3[i].getVariableNumber(gdjs.MainCode.GDplayerObjects3[i].getVariables().get("Health")) != 0 ) {
        gdjs.MainCode.condition2IsTrue_0.val = true;
        gdjs.MainCode.GDplayerObjects3[k] = gdjs.MainCode.GDplayerObjects3[i];
        ++k;
    }
}
gdjs.MainCode.GDplayerObjects3.length = k;}}
}
if (gdjs.MainCode.condition2IsTrue_0.val) {
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDbulletObjects3Objects, Math.ceil((( gdjs.MainCode.GDenemyDOWNObjects3.length === 0 ) ? 0 :gdjs.MainCode.GDenemyDOWNObjects3[0].getPointX(""))), (( gdjs.MainCode.GDenemyDOWNObjects3.length === 0 ) ? 0 :gdjs.MainCode.GDenemyDOWNObjects3[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.MainCode.GDbulletObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDbulletObjects3[i].addForce(0, -(80), 1);
}
}{for(var i = 0, len = gdjs.MainCode.GDenemyDOWNObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDenemyDOWNObjects3[i].resetTimer("shoot");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "shoot.wav", false, 100, 1);
}}
}

}


};gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDbulletObjects2Objects = Hashtable.newFrom({"bullet": gdjs.MainCode.GDbulletObjects2});
gdjs.MainCode.eventsList17 = function(runtimeScene) {

};gdjs.MainCode.eventsList18 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("enemyLEFT"), gdjs.MainCode.GDenemyLEFTObjects2);

gdjs.MainCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDenemyLEFTObjects2.length;i<l;++i) {
    if ( gdjs.MainCode.GDenemyLEFTObjects2[i].getVariableBoolean(gdjs.MainCode.GDenemyLEFTObjects2[i].getVariables().get("side"), false) ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDenemyLEFTObjects2[k] = gdjs.MainCode.GDenemyLEFTObjects2[i];
        ++k;
    }
}
gdjs.MainCode.GDenemyLEFTObjects2.length = k;}if (gdjs.MainCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDenemyLEFTObjects2 */
{for(var i = 0, len = gdjs.MainCode.GDenemyLEFTObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDenemyLEFTObjects2[i].getBehavior("TopDownMovement").simulateDownKey();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("enemyLEFT"), gdjs.MainCode.GDenemyLEFTObjects2);

gdjs.MainCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDenemyLEFTObjects2.length;i<l;++i) {
    if ( gdjs.MainCode.GDenemyLEFTObjects2[i].getVariableBoolean(gdjs.MainCode.GDenemyLEFTObjects2[i].getVariables().get("side"), true) ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDenemyLEFTObjects2[k] = gdjs.MainCode.GDenemyLEFTObjects2[i];
        ++k;
    }
}
gdjs.MainCode.GDenemyLEFTObjects2.length = k;}if (gdjs.MainCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDenemyLEFTObjects2 */
{for(var i = 0, len = gdjs.MainCode.GDenemyLEFTObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDenemyLEFTObjects2[i].getBehavior("TopDownMovement").simulateUpKey();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("enemyLEFT"), gdjs.MainCode.GDenemyLEFTObjects1);

for(gdjs.MainCode.forEachIndex2 = 0;gdjs.MainCode.forEachIndex2 < gdjs.MainCode.GDenemyLEFTObjects1.length;++gdjs.MainCode.forEachIndex2) {
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.MainCode.GDplayerObjects2);
gdjs.MainCode.GDbulletObjects2.length = 0;

gdjs.MainCode.GDenemyLEFTObjects2.length = 0;


gdjs.MainCode.forEachTemporary2 = gdjs.MainCode.GDenemyLEFTObjects1[gdjs.MainCode.forEachIndex2];
gdjs.MainCode.GDenemyLEFTObjects2.push(gdjs.MainCode.forEachTemporary2);
gdjs.MainCode.condition0IsTrue_0.val = false;
gdjs.MainCode.condition1IsTrue_0.val = false;
gdjs.MainCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDenemyLEFTObjects2.length;i<l;++i) {
    if ( gdjs.MainCode.GDenemyLEFTObjects2[i].getTimerElapsedTimeInSecondsOrNaN("shoot") > 2 ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDenemyLEFTObjects2[k] = gdjs.MainCode.GDenemyLEFTObjects2[i];
        ++k;
    }
}
gdjs.MainCode.GDenemyLEFTObjects2.length = k;}if ( gdjs.MainCode.condition0IsTrue_0.val ) {
{
{gdjs.MainCode.conditionTrue_1 = gdjs.MainCode.condition1IsTrue_0;
gdjs.MainCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(8117844);
}
}if ( gdjs.MainCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDplayerObjects2.length;i<l;++i) {
    if ( gdjs.MainCode.GDplayerObjects2[i].getVariableNumber(gdjs.MainCode.GDplayerObjects2[i].getVariables().get("Health")) != 0 ) {
        gdjs.MainCode.condition2IsTrue_0.val = true;
        gdjs.MainCode.GDplayerObjects2[k] = gdjs.MainCode.GDplayerObjects2[i];
        ++k;
    }
}
gdjs.MainCode.GDplayerObjects2.length = k;}}
}
if (gdjs.MainCode.condition2IsTrue_0.val) {
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDbulletObjects2Objects, (( gdjs.MainCode.GDenemyLEFTObjects2.length === 0 ) ? 0 :gdjs.MainCode.GDenemyLEFTObjects2[0].getPointX("")), Math.ceil((( gdjs.MainCode.GDenemyLEFTObjects2.length === 0 ) ? 0 :gdjs.MainCode.GDenemyLEFTObjects2[0].getPointY(""))), "");
}{for(var i = 0, len = gdjs.MainCode.GDbulletObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDbulletObjects2[i].addForce(80, 0, 1);
}
}{for(var i = 0, len = gdjs.MainCode.GDbulletObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDbulletObjects2[i].rotateTowardAngle(90, 0, runtimeScene);
}
}{for(var i = 0, len = gdjs.MainCode.GDenemyLEFTObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDenemyLEFTObjects2[i].resetTimer("shoot");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "shoot.wav", false, 100, 1);
}}
}

}


};gdjs.MainCode.eventsList19 = function(runtimeScene) {

{


gdjs.MainCode.eventsList12(runtimeScene);
}


{


gdjs.MainCode.eventsList14(runtimeScene);
}


{


gdjs.MainCode.eventsList16(runtimeScene);
}


{


gdjs.MainCode.eventsList18(runtimeScene);
}


};gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.MainCode.GDplayerObjects2});
gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDkillerorbObjects2Objects = Hashtable.newFrom({"killerorb": gdjs.MainCode.GDkillerorbObjects2});
gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.MainCode.GDplayerObjects2});
gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDkillerorbObjects2Objects = Hashtable.newFrom({"killerorb": gdjs.MainCode.GDkillerorbObjects2});
gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDrepelbulletObjects2Objects = Hashtable.newFrom({"repelbullet": gdjs.MainCode.GDrepelbulletObjects2});
gdjs.MainCode.eventsList20 = function(runtimeScene) {

{


gdjs.MainCode.condition0IsTrue_0.val = false;
{
{gdjs.MainCode.conditionTrue_1 = gdjs.MainCode.condition0IsTrue_0;
gdjs.MainCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(8120188);
}
}if (gdjs.MainCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDplayerObjects2 */
gdjs.MainCode.GDrepelbulletObjects2.length = 0;

{gdjs.evtTools.sound.playSound(runtimeScene, "poweup.wav", false, 60, 1);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDrepelbulletObjects2Objects, (( gdjs.MainCode.GDplayerObjects2.length === 0 ) ? 0 :gdjs.MainCode.GDplayerObjects2[0].getPointX("")), (( gdjs.MainCode.GDplayerObjects2.length === 0 ) ? 0 :gdjs.MainCode.GDplayerObjects2[0].getPointY("")), "");
}{gdjs.evtTools.variable.toggleVariableBoolean(runtimeScene.getVariables().get("killer"));
}}

}


};gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDbulletObjects2Objects = Hashtable.newFrom({"bullet": gdjs.MainCode.GDbulletObjects2});
gdjs.MainCode.asyncCallback8122484 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("repelbullet"), gdjs.MainCode.GDrepelbulletObjects4);

{for(var i = 0, len = gdjs.MainCode.GDrepelbulletObjects4.length ;i < len;++i) {
    gdjs.MainCode.GDrepelbulletObjects4[i].deleteFromScene(runtimeScene);
}
}}
gdjs.MainCode.eventsList21 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
/* Don't save repelbullet as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.MainCode.asyncCallback8122484(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.asyncCallback8122188 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.variable.toggleVariableBoolean(runtimeScene.getVariables().get("killer"));
}
{ //Subevents
gdjs.MainCode.eventsList21(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.MainCode.eventsList22 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.MainCode.GDrepelbulletObjects2) asyncObjectsList.addObject("repelbullet", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(6), (runtimeScene) => (gdjs.MainCode.asyncCallback8122188(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDbulletObjects2Objects = Hashtable.newFrom({"bullet": gdjs.MainCode.GDbulletObjects2});
gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDrepelbulletObjects2Objects = Hashtable.newFrom({"repelbullet": gdjs.MainCode.GDrepelbulletObjects2});
gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDkillerorbObjects1Objects = Hashtable.newFrom({"killerorb": gdjs.MainCode.GDkillerorbObjects1});
gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDbulletObjects1Objects = Hashtable.newFrom({"bullet": gdjs.MainCode.GDbulletObjects1});
gdjs.MainCode.eventsList23 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.MainCode.GDplayerObjects2);

gdjs.MainCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDplayerObjects2.length;i<l;++i) {
    if ( gdjs.MainCode.GDplayerObjects2[i].getTimerElapsedTimeInSecondsOrNaN("mega") < 10 ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDplayerObjects2[k] = gdjs.MainCode.GDplayerObjects2[i];
        ++k;
    }
}
gdjs.MainCode.GDplayerObjects2.length = k;}if (gdjs.MainCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("killerorb"), gdjs.MainCode.GDkillerorbObjects2);
/* Reuse gdjs.MainCode.GDplayerObjects2 */
{gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.func(runtimeScene, gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDplayerObjects2Objects, gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDkillerorbObjects2Objects, 2, 360, 15, -(360), "", 10000, 0, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.MainCode.GDplayerObjects2);

gdjs.MainCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDplayerObjects2.length;i<l;++i) {
    if ( gdjs.MainCode.GDplayerObjects2[i].getTimerElapsedTimeInSecondsOrNaN("mega") > 10 ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDplayerObjects2[k] = gdjs.MainCode.GDplayerObjects2[i];
        ++k;
    }
}
gdjs.MainCode.GDplayerObjects2.length = k;}if (gdjs.MainCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("killerorb"), gdjs.MainCode.GDkillerorbObjects2);
/* Reuse gdjs.MainCode.GDplayerObjects2 */
{gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.func(runtimeScene, gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDplayerObjects2Objects, gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDkillerorbObjects2Objects, 5, 780, 20, -(780), "", 10000, 0, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
{ //Subevents
gdjs.MainCode.eventsList20(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("bullet"), gdjs.MainCode.GDbulletObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.MainCode.GDplayerObjects2);

gdjs.MainCode.condition0IsTrue_0.val = false;
gdjs.MainCode.condition1IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.object.pickNearestObject(gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDbulletObjects2Objects, (( gdjs.MainCode.GDplayerObjects2.length === 0 ) ? 0 :gdjs.MainCode.GDplayerObjects2[0].getPointX("")), (( gdjs.MainCode.GDplayerObjects2.length === 0 ) ? 0 :gdjs.MainCode.GDplayerObjects2[0].getPointY("")), false);
}if ( gdjs.MainCode.condition0IsTrue_0.val ) {
{
gdjs.MainCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getVariables().get("killer"), true);
}}
if (gdjs.MainCode.condition1IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDbulletObjects2 */
gdjs.copyArray(runtimeScene.getObjects("repelbullet"), gdjs.MainCode.GDrepelbulletObjects2);
{for(var i = 0, len = gdjs.MainCode.GDrepelbulletObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDrepelbulletObjects2[i].addForceTowardObject((gdjs.MainCode.GDbulletObjects2.length !== 0 ? gdjs.MainCode.GDbulletObjects2[0] : null), 100, 0);
}
}
{ //Subevents
gdjs.MainCode.eventsList22(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("bullet"), gdjs.MainCode.GDbulletObjects2);
gdjs.copyArray(runtimeScene.getObjects("repelbullet"), gdjs.MainCode.GDrepelbulletObjects2);

gdjs.MainCode.condition0IsTrue_0.val = false;
gdjs.MainCode.condition1IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDbulletObjects2Objects, gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDrepelbulletObjects2Objects, false, runtimeScene, false);
}if ( gdjs.MainCode.condition0IsTrue_0.val ) {
{
{gdjs.MainCode.conditionTrue_1 = gdjs.MainCode.condition1IsTrue_0;
gdjs.MainCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(8123164);
}
}}
if (gdjs.MainCode.condition1IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDbulletObjects2 */
{for(var i = 0, len = gdjs.MainCode.GDbulletObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDbulletObjects2[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getVariables().get("bullet").add(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "expl.wav", false, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.MainCode.GDplayerObjects2);

gdjs.MainCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDplayerObjects2.length;i<l;++i) {
    if ( gdjs.MainCode.GDplayerObjects2[i].getTimerElapsedTimeInSecondsOrNaN("mega") > 12 ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDplayerObjects2[k] = gdjs.MainCode.GDplayerObjects2[i];
        ++k;
    }
}
gdjs.MainCode.GDplayerObjects2.length = k;}if (gdjs.MainCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDplayerObjects2 */
{for(var i = 0, len = gdjs.MainCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDplayerObjects2[i].resetTimer("mega");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("bullet"), gdjs.MainCode.GDbulletObjects1);
gdjs.copyArray(runtimeScene.getObjects("killerorb"), gdjs.MainCode.GDkillerorbObjects1);

gdjs.MainCode.condition0IsTrue_0.val = false;
gdjs.MainCode.condition1IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDkillerorbObjects1Objects, gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDbulletObjects1Objects, false, runtimeScene, false);
}if ( gdjs.MainCode.condition0IsTrue_0.val ) {
{
{gdjs.MainCode.conditionTrue_1 = gdjs.MainCode.condition1IsTrue_0;
gdjs.MainCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(8125012);
}
}}
if (gdjs.MainCode.condition1IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDbulletObjects1 */
{for(var i = 0, len = gdjs.MainCode.GDbulletObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDbulletObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 0.3, 0.1, 0.1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtTools.sound.playSound(runtimeScene, "expl.wav", false, 100, gdjs.randomInRange(1, 4));
}{runtimeScene.getVariables().get("bullet").add(1);
}}

}


};gdjs.MainCode.asyncCallback14679892 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("rip"), gdjs.MainCode.GDripObjects5);

gdjs.copyArray(runtimeScene.getObjects("time"), gdjs.MainCode.GDtimeObjects5);
{for(var i = 0, len = gdjs.MainCode.GDtimeObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDtimeObjects5[i].getBehavior("Tween").addObjectPositionTween("pos", (( gdjs.MainCode.GDripObjects5.length === 0 ) ? 0 :gdjs.MainCode.GDripObjects5[0].getPointX("")), (( gdjs.MainCode.GDripObjects5.length === 0 ) ? 0 :gdjs.MainCode.GDripObjects5[0].getPointY("")) + 40, "bouncePast", 300, false);
}
}}
gdjs.MainCode.eventsList24 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.MainCode.GDripObjects4) asyncObjectsList.addObject("rip", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.MainCode.asyncCallback14679892(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.asyncCallback8129476 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.MainCode.GDScoreObjects4);
gdjs.copyArray(asyncObjectsList.getObjects("rip"), gdjs.MainCode.GDripObjects4);

{for(var i = 0, len = gdjs.MainCode.GDScoreObjects4.length ;i < len;++i) {
    gdjs.MainCode.GDScoreObjects4[i].getBehavior("Tween").addObjectPositionTween("pos", (( gdjs.MainCode.GDripObjects4.length === 0 ) ? 0 :gdjs.MainCode.GDripObjects4[0].getPointX("")), (( gdjs.MainCode.GDripObjects4.length === 0 ) ? 0 :gdjs.MainCode.GDripObjects4[0].getPointY("")) + 30, "bouncePast", 300, false);
}
}
{ //Subevents
gdjs.MainCode.eventsList24(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.MainCode.eventsList25 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.MainCode.GDripObjects3) asyncObjectsList.addObject("rip", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.MainCode.asyncCallback8129476(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.asyncCallback8129212 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("killedBullet"), gdjs.MainCode.GDkilledBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("rip"), gdjs.MainCode.GDripObjects3);
{for(var i = 0, len = gdjs.MainCode.GDkilledBulletObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDkilledBulletObjects3[i].getBehavior("Tween").addObjectPositionTween("pos", (( gdjs.MainCode.GDripObjects3.length === 0 ) ? 0 :gdjs.MainCode.GDripObjects3[0].getPointX("")), (( gdjs.MainCode.GDripObjects3.length === 0 ) ? 0 :gdjs.MainCode.GDripObjects3[0].getPointY("")) + 20, "bouncePast", 300, false);
}
}
{ //Subevents
gdjs.MainCode.eventsList25(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.MainCode.eventsList26 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.4), (runtimeScene) => (gdjs.MainCode.asyncCallback8129212(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.asyncCallback8132052 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "HomeScreen", false);
}}
gdjs.MainCode.eventsList27 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(3), (runtimeScene) => (gdjs.MainCode.asyncCallback8132052(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.asyncCallback9836100 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("rip"), gdjs.MainCode.GDripObjects3);
{gdjs.evtTools.camera.setCameraX(runtimeScene, gdjs.evtTools.common.lerp(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), (( gdjs.MainCode.GDripObjects3.length === 0 ) ? 0 :gdjs.MainCode.GDripObjects3[0].getPointX("center")), 0.05), "", 0);
}{gdjs.evtTools.camera.setCameraY(runtimeScene, gdjs.evtTools.common.lerp(gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0), (( gdjs.MainCode.GDripObjects3.length === 0 ) ? 0 :gdjs.MainCode.GDripObjects3[0].getPointY("center")), 0.05), "", 0);
}{gdjs.evtTools.camera.setCameraZoom(runtimeScene, gdjs.evtTools.common.lerp(gdjs.evtTools.camera.getCameraZoom(runtimeScene, "", 0), 7.5, 0.02), "", 0);
}
{ //Subevents
gdjs.MainCode.eventsList27(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.MainCode.eventsList28 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.MainCode.asyncCallback9836100(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDpauseObjects2Objects = Hashtable.newFrom({"pause": gdjs.MainCode.GDpauseObjects2});
gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDhomeObjects2Objects = Hashtable.newFrom({"home": gdjs.MainCode.GDhomeObjects2});
gdjs.MainCode.eventsList29 = function(runtimeScene) {

{


gdjs.MainCode.condition0IsTrue_0.val = false;
gdjs.MainCode.condition1IsTrue_0.val = false;
gdjs.MainCode.condition2IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "sec") >= 1;
}if ( gdjs.MainCode.condition0IsTrue_0.val ) {
{
gdjs.MainCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getVariables().get("death"), false);
}if ( gdjs.MainCode.condition1IsTrue_0.val ) {
{
{gdjs.MainCode.conditionTrue_1 = gdjs.MainCode.condition2IsTrue_0;
gdjs.MainCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13661884);
}
}}
}
if (gdjs.MainCode.condition2IsTrue_0.val) {
{runtimeScene.getVariables().get("second").add(1);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "sec");
}}

}


{


gdjs.MainCode.condition0IsTrue_0.val = false;
gdjs.MainCode.condition1IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("second")) >= 60;
}if ( gdjs.MainCode.condition0IsTrue_0.val ) {
{
{gdjs.MainCode.conditionTrue_1 = gdjs.MainCode.condition1IsTrue_0;
gdjs.MainCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12155140);
}
}}
if (gdjs.MainCode.condition1IsTrue_0.val) {
{runtimeScene.getVariables().get("second").setNumber(0);
}{runtimeScene.getVariables().get("minute").add(1);
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("time"), gdjs.MainCode.GDtimeObjects1);
{for(var i = 0, len = gdjs.MainCode.GDtimeObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDtimeObjects1[i].setText("Survival: " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("minute"))) + ":" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("second"))));
}
}}

}


};gdjs.MainCode.eventsList30 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.MainCode.GDScoreObjects2);
gdjs.copyArray(runtimeScene.getObjects("killedBullet"), gdjs.MainCode.GDkilledBulletObjects2);
{for(var i = 0, len = gdjs.MainCode.GDkilledBulletObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDkilledBulletObjects2[i].setText("Bullets Destroyed: " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("bullet"))));
}
}{for(var i = 0, len = gdjs.MainCode.GDScoreObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDScoreObjects2[i].setText("Total Score: " + gdjs.evtTools.common.toString(Math.ceil(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("bullet")) / 2)));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.MainCode.GDplayerObjects2);

gdjs.MainCode.condition0IsTrue_0.val = false;
gdjs.MainCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDplayerObjects2.length;i<l;++i) {
    if ( gdjs.MainCode.GDplayerObjects2[i].getVariableNumber(gdjs.MainCode.GDplayerObjects2[i].getVariables().get("Health")) == 0 ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDplayerObjects2[k] = gdjs.MainCode.GDplayerObjects2[i];
        ++k;
    }
}
gdjs.MainCode.GDplayerObjects2.length = k;}if ( gdjs.MainCode.condition0IsTrue_0.val ) {
{
{gdjs.MainCode.conditionTrue_1 = gdjs.MainCode.condition1IsTrue_0;
gdjs.MainCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(8128364);
}
}}
if (gdjs.MainCode.condition1IsTrue_0.val) {
{gdjs.evtTools.variable.toggleVariableBoolean(runtimeScene.getVariables().get("death"));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.MainCode.GDplayerObjects2);

gdjs.MainCode.condition0IsTrue_0.val = false;
gdjs.MainCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDplayerObjects2.length;i<l;++i) {
    if ( gdjs.MainCode.GDplayerObjects2[i].getVariableNumber(gdjs.MainCode.GDplayerObjects2[i].getVariables().get("Health")) == 0 ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDplayerObjects2[k] = gdjs.MainCode.GDplayerObjects2[i];
        ++k;
    }
}
gdjs.MainCode.GDplayerObjects2.length = k;}if ( gdjs.MainCode.condition0IsTrue_0.val ) {
{
{gdjs.MainCode.conditionTrue_1 = gdjs.MainCode.condition1IsTrue_0;
gdjs.MainCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(8129004);
}
}}
if (gdjs.MainCode.condition1IsTrue_0.val) {

{ //Subevents
gdjs.MainCode.eventsList26(runtimeScene);} //End of subevents
}

}


{


gdjs.MainCode.condition0IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getVariables().get("death"), true);
}if (gdjs.MainCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainCode.eventsList28(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("pause"), gdjs.MainCode.GDpauseObjects2);

gdjs.MainCode.condition0IsTrue_0.val = false;
gdjs.MainCode.condition1IsTrue_0.val = false;
gdjs.MainCode.condition2IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDpauseObjects2Objects, runtimeScene, true, false);
}if ( gdjs.MainCode.condition0IsTrue_0.val ) {
{
gdjs.MainCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.MainCode.condition1IsTrue_0.val ) {
{
{gdjs.MainCode.conditionTrue_1 = gdjs.MainCode.condition2IsTrue_0;
gdjs.MainCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(8132700);
}
}}
}
if (gdjs.MainCode.condition2IsTrue_0.val) {
{gdjs.evtTools.variable.toggleVariableBoolean(runtimeScene.getVariables().get("pause"));
}}

}


{


gdjs.MainCode.condition0IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getVariables().get("pause"), true);
}if (gdjs.MainCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("pause"), gdjs.MainCode.GDpauseObjects2);
{gdjs.evtTools.sound.stopMusicOnChannel(runtimeScene, 0);
}{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 0);
}{for(var i = 0, len = gdjs.MainCode.GDpauseObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDpauseObjects2[i].setAnimation(1);
}
}}

}


{


gdjs.MainCode.condition0IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getVariables().get("pause"), false);
}if (gdjs.MainCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("pause"), gdjs.MainCode.GDpauseObjects2);
{gdjs.evtTools.sound.continueMusicOnChannel(runtimeScene, 0);
}{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 1);
}{for(var i = 0, len = gdjs.MainCode.GDpauseObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDpauseObjects2[i].setAnimation(0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("home"), gdjs.MainCode.GDhomeObjects2);

gdjs.MainCode.condition0IsTrue_0.val = false;
gdjs.MainCode.condition1IsTrue_0.val = false;
gdjs.MainCode.condition2IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDhomeObjects2Objects, runtimeScene, true, false);
}if ( gdjs.MainCode.condition0IsTrue_0.val ) {
{
gdjs.MainCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.MainCode.condition1IsTrue_0.val ) {
{
{gdjs.MainCode.conditionTrue_1 = gdjs.MainCode.condition2IsTrue_0;
gdjs.MainCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(14994828);
}
}}
}
if (gdjs.MainCode.condition2IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "HomeScreen", false);
}}

}


{


gdjs.MainCode.eventsList29(runtimeScene);
}


};gdjs.MainCode.eventsList31 = function(runtimeScene) {

{



}


{


gdjs.MainCode.condition0IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.MainCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.preloadMusic(runtimeScene, "..\\assets\\game music\\GameMusic.wav");
}
{ //Subevents
gdjs.MainCode.eventsList0(runtimeScene);} //End of subevents
}

}


{


{
{gdjs.evtTools.sound.setMusicOnChannelVolume(runtimeScene, 0, gdjs.evtTools.common.lerp(gdjs.evtTools.sound.getMusicOnChannelVolume(runtimeScene, 0), 100, 0.05));
}}

}


{


gdjs.MainCode.condition0IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.MainCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("blocker"), gdjs.MainCode.GDblockerObjects1);
gdjs.copyArray(runtimeScene.getObjects("detect"), gdjs.MainCode.GDdetectObjects1);
gdjs.copyArray(runtimeScene.getObjects("enemyDOWN"), gdjs.MainCode.GDenemyDOWNObjects1);
gdjs.copyArray(runtimeScene.getObjects("enemyLEFT"), gdjs.MainCode.GDenemyLEFTObjects1);
gdjs.copyArray(runtimeScene.getObjects("enemyRIGHT"), gdjs.MainCode.GDenemyRIGHTObjects1);
gdjs.copyArray(runtimeScene.getObjects("enemyUP"), gdjs.MainCode.GDenemyUPObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.MainCode.GDplayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("playerhitbox"), gdjs.MainCode.GDplayerhitboxObjects1);
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 3.5, "", 0);
}{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.MainCode.GDplayerObjects1.length !== 0 ? gdjs.MainCode.GDplayerObjects1[0] : null), true, "", 0);
}{for(var i = 0, len = gdjs.MainCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDplayerObjects1[i].resetTimer("coolD");
}
}{for(var i = 0, len = gdjs.MainCode.GDplayerhitboxObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDplayerhitboxObjects1[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDblockerObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDblockerObjects1[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDdetectObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDdetectObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.MainCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDplayerObjects1[i].putAroundObject((gdjs.MainCode.GDplayerhitboxObjects1.length !== 0 ? gdjs.MainCode.GDplayerhitboxObjects1[0] : null), 0, (gdjs.MainCode.GDplayerObjects1[i].getAngle()));
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "PickVar");
}{for(var i = 0, len = gdjs.MainCode.GDenemyUPObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDenemyUPObjects1[i].resetTimer("shoot");
}
}{for(var i = 0, len = gdjs.MainCode.GDenemyDOWNObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDenemyDOWNObjects1[i].resetTimer("shoot");
}
}{for(var i = 0, len = gdjs.MainCode.GDenemyLEFTObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDenemyLEFTObjects1[i].resetTimer("shoot");
}
}{for(var i = 0, len = gdjs.MainCode.GDenemyRIGHTObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDenemyRIGHTObjects1[i].resetTimer("shoot");
}
}{for(var i = 0, len = gdjs.MainCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDplayerObjects1[i].resetTimer("mega");
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "idledetect");
}{runtimeScene.getVariables().get("bullet").setNumber(0);
}{for(var i = 0, len = gdjs.MainCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDplayerObjects1[i].getBehavior("PlatformerObject").setGravity(0);
}
}{for(var i = 0, len = gdjs.MainCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDplayerObjects1[i].resetTimer("regen");
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "sec");
}}

}


{


gdjs.MainCode.condition0IsTrue_0.val = false;
gdjs.MainCode.condition1IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.input.anyKeyPressed(runtimeScene);
}if ( gdjs.MainCode.condition0IsTrue_0.val ) {
{
{gdjs.MainCode.conditionTrue_1 = gdjs.MainCode.condition1IsTrue_0;
gdjs.MainCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11221916);
}
}}
if (gdjs.MainCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "idledetect");
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("blocker"), gdjs.MainCode.GDblockerObjects1);
gdjs.copyArray(runtimeScene.getObjects("playerhitbox"), gdjs.MainCode.GDplayerhitboxObjects1);
{runtimeScene.getVariables().get("playerX").setNumber((( gdjs.MainCode.GDplayerhitboxObjects1.length === 0 ) ? 0 :gdjs.MainCode.GDplayerhitboxObjects1[0].getPointX("")));
}{for(var i = 0, len = gdjs.MainCode.GDplayerhitboxObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDplayerhitboxObjects1[i].separateFromObjectsList(gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDblockerObjects1Objects, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.MainCode.GDplayerObjects1);

gdjs.MainCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDplayerObjects1.length;i<l;++i) {
    if ( gdjs.MainCode.GDplayerObjects1[i].getVariableNumber(gdjs.MainCode.GDplayerObjects1[i].getVariables().get("Health")) != 0 ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDplayerObjects1[k] = gdjs.MainCode.GDplayerObjects1[i];
        ++k;
    }
}
gdjs.MainCode.GDplayerObjects1.length = k;}if (gdjs.MainCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("maintile"), gdjs.MainCode.GDmaintileObjects1);
{gdjs.evtTools.camera.clampCamera(runtimeScene, 206, 0, 0, 206, "", 0);
}{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.MainCode.GDmaintileObjects1.length !== 0 ? gdjs.MainCode.GDmaintileObjects1[0] : null), true, "", 0);
}}

}


{



}


{


gdjs.MainCode.eventsList3(runtimeScene);
}


{


gdjs.MainCode.eventsList9(runtimeScene);
}


{


gdjs.MainCode.eventsList10(runtimeScene);
}


{


gdjs.MainCode.eventsList19(runtimeScene);
}


{


gdjs.MainCode.eventsList23(runtimeScene);
}


{


gdjs.MainCode.eventsList30(runtimeScene);
}


};

gdjs.MainCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.MainCode.GDplayerObjects1.length = 0;
gdjs.MainCode.GDplayerObjects2.length = 0;
gdjs.MainCode.GDplayerObjects3.length = 0;
gdjs.MainCode.GDplayerObjects4.length = 0;
gdjs.MainCode.GDplayerObjects5.length = 0;
gdjs.MainCode.GDGuide2Objects1.length = 0;
gdjs.MainCode.GDGuide2Objects2.length = 0;
gdjs.MainCode.GDGuide2Objects3.length = 0;
gdjs.MainCode.GDGuide2Objects4.length = 0;
gdjs.MainCode.GDGuide2Objects5.length = 0;
gdjs.MainCode.GDGuide22Objects1.length = 0;
gdjs.MainCode.GDGuide22Objects2.length = 0;
gdjs.MainCode.GDGuide22Objects3.length = 0;
gdjs.MainCode.GDGuide22Objects4.length = 0;
gdjs.MainCode.GDGuide22Objects5.length = 0;
gdjs.MainCode.GDGuide23Objects1.length = 0;
gdjs.MainCode.GDGuide23Objects2.length = 0;
gdjs.MainCode.GDGuide23Objects3.length = 0;
gdjs.MainCode.GDGuide23Objects4.length = 0;
gdjs.MainCode.GDGuide23Objects5.length = 0;
gdjs.MainCode.GDTitleObjects1.length = 0;
gdjs.MainCode.GDTitleObjects2.length = 0;
gdjs.MainCode.GDTitleObjects3.length = 0;
gdjs.MainCode.GDTitleObjects4.length = 0;
gdjs.MainCode.GDTitleObjects5.length = 0;
gdjs.MainCode.GDgrass1Objects1.length = 0;
gdjs.MainCode.GDgrass1Objects2.length = 0;
gdjs.MainCode.GDgrass1Objects3.length = 0;
gdjs.MainCode.GDgrass1Objects4.length = 0;
gdjs.MainCode.GDgrass1Objects5.length = 0;
gdjs.MainCode.GDgrass2Objects1.length = 0;
gdjs.MainCode.GDgrass2Objects2.length = 0;
gdjs.MainCode.GDgrass2Objects3.length = 0;
gdjs.MainCode.GDgrass2Objects4.length = 0;
gdjs.MainCode.GDgrass2Objects5.length = 0;
gdjs.MainCode.GDgrass3Objects1.length = 0;
gdjs.MainCode.GDgrass3Objects2.length = 0;
gdjs.MainCode.GDgrass3Objects3.length = 0;
gdjs.MainCode.GDgrass3Objects4.length = 0;
gdjs.MainCode.GDgrass3Objects5.length = 0;
gdjs.MainCode.GDgrass4Objects1.length = 0;
gdjs.MainCode.GDgrass4Objects2.length = 0;
gdjs.MainCode.GDgrass4Objects3.length = 0;
gdjs.MainCode.GDgrass4Objects4.length = 0;
gdjs.MainCode.GDgrass4Objects5.length = 0;
gdjs.MainCode.GDassetsObjects1.length = 0;
gdjs.MainCode.GDassetsObjects2.length = 0;
gdjs.MainCode.GDassetsObjects3.length = 0;
gdjs.MainCode.GDassetsObjects4.length = 0;
gdjs.MainCode.GDassetsObjects5.length = 0;
gdjs.MainCode.GDmusicObjects1.length = 0;
gdjs.MainCode.GDmusicObjects2.length = 0;
gdjs.MainCode.GDmusicObjects3.length = 0;
gdjs.MainCode.GDmusicObjects4.length = 0;
gdjs.MainCode.GDmusicObjects5.length = 0;
gdjs.MainCode.GDmusic2Objects1.length = 0;
gdjs.MainCode.GDmusic2Objects2.length = 0;
gdjs.MainCode.GDmusic2Objects3.length = 0;
gdjs.MainCode.GDmusic2Objects4.length = 0;
gdjs.MainCode.GDmusic2Objects5.length = 0;
gdjs.MainCode.GDboneObjects1.length = 0;
gdjs.MainCode.GDboneObjects2.length = 0;
gdjs.MainCode.GDboneObjects3.length = 0;
gdjs.MainCode.GDboneObjects4.length = 0;
gdjs.MainCode.GDboneObjects5.length = 0;
gdjs.MainCode.GDskullObjects1.length = 0;
gdjs.MainCode.GDskullObjects2.length = 0;
gdjs.MainCode.GDskullObjects3.length = 0;
gdjs.MainCode.GDskullObjects4.length = 0;
gdjs.MainCode.GDskullObjects5.length = 0;
gdjs.MainCode.GDplayerhitboxObjects1.length = 0;
gdjs.MainCode.GDplayerhitboxObjects2.length = 0;
gdjs.MainCode.GDplayerhitboxObjects3.length = 0;
gdjs.MainCode.GDplayerhitboxObjects4.length = 0;
gdjs.MainCode.GDplayerhitboxObjects5.length = 0;
gdjs.MainCode.GDenemyUPObjects1.length = 0;
gdjs.MainCode.GDenemyUPObjects2.length = 0;
gdjs.MainCode.GDenemyUPObjects3.length = 0;
gdjs.MainCode.GDenemyUPObjects4.length = 0;
gdjs.MainCode.GDenemyUPObjects5.length = 0;
gdjs.MainCode.GDenemyDOWNObjects1.length = 0;
gdjs.MainCode.GDenemyDOWNObjects2.length = 0;
gdjs.MainCode.GDenemyDOWNObjects3.length = 0;
gdjs.MainCode.GDenemyDOWNObjects4.length = 0;
gdjs.MainCode.GDenemyDOWNObjects5.length = 0;
gdjs.MainCode.GDenemyLEFTObjects1.length = 0;
gdjs.MainCode.GDenemyLEFTObjects2.length = 0;
gdjs.MainCode.GDenemyLEFTObjects3.length = 0;
gdjs.MainCode.GDenemyLEFTObjects4.length = 0;
gdjs.MainCode.GDenemyLEFTObjects5.length = 0;
gdjs.MainCode.GDenemyRIGHTObjects1.length = 0;
gdjs.MainCode.GDenemyRIGHTObjects2.length = 0;
gdjs.MainCode.GDenemyRIGHTObjects3.length = 0;
gdjs.MainCode.GDenemyRIGHTObjects4.length = 0;
gdjs.MainCode.GDenemyRIGHTObjects5.length = 0;
gdjs.MainCode.GDbulletObjects1.length = 0;
gdjs.MainCode.GDbulletObjects2.length = 0;
gdjs.MainCode.GDbulletObjects3.length = 0;
gdjs.MainCode.GDbulletObjects4.length = 0;
gdjs.MainCode.GDbulletObjects5.length = 0;
gdjs.MainCode.GDmaintileObjects1.length = 0;
gdjs.MainCode.GDmaintileObjects2.length = 0;
gdjs.MainCode.GDmaintileObjects3.length = 0;
gdjs.MainCode.GDmaintileObjects4.length = 0;
gdjs.MainCode.GDmaintileObjects5.length = 0;
gdjs.MainCode.GDtilesObjects1.length = 0;
gdjs.MainCode.GDtilesObjects2.length = 0;
gdjs.MainCode.GDtilesObjects3.length = 0;
gdjs.MainCode.GDtilesObjects4.length = 0;
gdjs.MainCode.GDtilesObjects5.length = 0;
gdjs.MainCode.GDblockerObjects1.length = 0;
gdjs.MainCode.GDblockerObjects2.length = 0;
gdjs.MainCode.GDblockerObjects3.length = 0;
gdjs.MainCode.GDblockerObjects4.length = 0;
gdjs.MainCode.GDblockerObjects5.length = 0;
gdjs.MainCode.GDdetectObjects1.length = 0;
gdjs.MainCode.GDdetectObjects2.length = 0;
gdjs.MainCode.GDdetectObjects3.length = 0;
gdjs.MainCode.GDdetectObjects4.length = 0;
gdjs.MainCode.GDdetectObjects5.length = 0;
gdjs.MainCode.GDkillerorbObjects1.length = 0;
gdjs.MainCode.GDkillerorbObjects2.length = 0;
gdjs.MainCode.GDkillerorbObjects3.length = 0;
gdjs.MainCode.GDkillerorbObjects4.length = 0;
gdjs.MainCode.GDkillerorbObjects5.length = 0;
gdjs.MainCode.GDbombtileObjects1.length = 0;
gdjs.MainCode.GDbombtileObjects2.length = 0;
gdjs.MainCode.GDbombtileObjects3.length = 0;
gdjs.MainCode.GDbombtileObjects4.length = 0;
gdjs.MainCode.GDbombtileObjects5.length = 0;
gdjs.MainCode.GDblastObjects1.length = 0;
gdjs.MainCode.GDblastObjects2.length = 0;
gdjs.MainCode.GDblastObjects3.length = 0;
gdjs.MainCode.GDblastObjects4.length = 0;
gdjs.MainCode.GDblastObjects5.length = 0;
gdjs.MainCode.GDhealthObjects1.length = 0;
gdjs.MainCode.GDhealthObjects2.length = 0;
gdjs.MainCode.GDhealthObjects3.length = 0;
gdjs.MainCode.GDhealthObjects4.length = 0;
gdjs.MainCode.GDhealthObjects5.length = 0;
gdjs.MainCode.GDripObjects1.length = 0;
gdjs.MainCode.GDripObjects2.length = 0;
gdjs.MainCode.GDripObjects3.length = 0;
gdjs.MainCode.GDripObjects4.length = 0;
gdjs.MainCode.GDripObjects5.length = 0;
gdjs.MainCode.GDkilledBulletObjects1.length = 0;
gdjs.MainCode.GDkilledBulletObjects2.length = 0;
gdjs.MainCode.GDkilledBulletObjects3.length = 0;
gdjs.MainCode.GDkilledBulletObjects4.length = 0;
gdjs.MainCode.GDkilledBulletObjects5.length = 0;
gdjs.MainCode.GDtimeObjects1.length = 0;
gdjs.MainCode.GDtimeObjects2.length = 0;
gdjs.MainCode.GDtimeObjects3.length = 0;
gdjs.MainCode.GDtimeObjects4.length = 0;
gdjs.MainCode.GDtimeObjects5.length = 0;
gdjs.MainCode.GDScoreObjects1.length = 0;
gdjs.MainCode.GDScoreObjects2.length = 0;
gdjs.MainCode.GDScoreObjects3.length = 0;
gdjs.MainCode.GDScoreObjects4.length = 0;
gdjs.MainCode.GDScoreObjects5.length = 0;
gdjs.MainCode.GDrepelbulletObjects1.length = 0;
gdjs.MainCode.GDrepelbulletObjects2.length = 0;
gdjs.MainCode.GDrepelbulletObjects3.length = 0;
gdjs.MainCode.GDrepelbulletObjects4.length = 0;
gdjs.MainCode.GDrepelbulletObjects5.length = 0;
gdjs.MainCode.GDpauseObjects1.length = 0;
gdjs.MainCode.GDpauseObjects2.length = 0;
gdjs.MainCode.GDpauseObjects3.length = 0;
gdjs.MainCode.GDpauseObjects4.length = 0;
gdjs.MainCode.GDpauseObjects5.length = 0;
gdjs.MainCode.GDhomeObjects1.length = 0;
gdjs.MainCode.GDhomeObjects2.length = 0;
gdjs.MainCode.GDhomeObjects3.length = 0;
gdjs.MainCode.GDhomeObjects4.length = 0;
gdjs.MainCode.GDhomeObjects5.length = 0;

gdjs.MainCode.eventsList31(runtimeScene);
return;

}

gdjs['MainCode'] = gdjs.MainCode;

gdjs.HomeScreenCode = {};
gdjs.HomeScreenCode.GDplayerObjects1= [];
gdjs.HomeScreenCode.GDplayerObjects2= [];
gdjs.HomeScreenCode.GDplayerObjects3= [];
gdjs.HomeScreenCode.GDGuide2Objects1= [];
gdjs.HomeScreenCode.GDGuide2Objects2= [];
gdjs.HomeScreenCode.GDGuide2Objects3= [];
gdjs.HomeScreenCode.GDGuide22Objects1= [];
gdjs.HomeScreenCode.GDGuide22Objects2= [];
gdjs.HomeScreenCode.GDGuide22Objects3= [];
gdjs.HomeScreenCode.GDGuide23Objects1= [];
gdjs.HomeScreenCode.GDGuide23Objects2= [];
gdjs.HomeScreenCode.GDGuide23Objects3= [];
gdjs.HomeScreenCode.GDTitleObjects1= [];
gdjs.HomeScreenCode.GDTitleObjects2= [];
gdjs.HomeScreenCode.GDTitleObjects3= [];
gdjs.HomeScreenCode.GDgrass1Objects1= [];
gdjs.HomeScreenCode.GDgrass1Objects2= [];
gdjs.HomeScreenCode.GDgrass1Objects3= [];
gdjs.HomeScreenCode.GDgrass2Objects1= [];
gdjs.HomeScreenCode.GDgrass2Objects2= [];
gdjs.HomeScreenCode.GDgrass2Objects3= [];
gdjs.HomeScreenCode.GDgrass3Objects1= [];
gdjs.HomeScreenCode.GDgrass3Objects2= [];
gdjs.HomeScreenCode.GDgrass3Objects3= [];
gdjs.HomeScreenCode.GDgrass4Objects1= [];
gdjs.HomeScreenCode.GDgrass4Objects2= [];
gdjs.HomeScreenCode.GDgrass4Objects3= [];
gdjs.HomeScreenCode.GDassetsObjects1= [];
gdjs.HomeScreenCode.GDassetsObjects2= [];
gdjs.HomeScreenCode.GDassetsObjects3= [];
gdjs.HomeScreenCode.GDmusicObjects1= [];
gdjs.HomeScreenCode.GDmusicObjects2= [];
gdjs.HomeScreenCode.GDmusicObjects3= [];
gdjs.HomeScreenCode.GDmusic2Objects1= [];
gdjs.HomeScreenCode.GDmusic2Objects2= [];
gdjs.HomeScreenCode.GDmusic2Objects3= [];
gdjs.HomeScreenCode.GDboneObjects1= [];
gdjs.HomeScreenCode.GDboneObjects2= [];
gdjs.HomeScreenCode.GDboneObjects3= [];
gdjs.HomeScreenCode.GDskullObjects1= [];
gdjs.HomeScreenCode.GDskullObjects2= [];
gdjs.HomeScreenCode.GDskullObjects3= [];
gdjs.HomeScreenCode.GDenemyObjects1= [];
gdjs.HomeScreenCode.GDenemyObjects2= [];
gdjs.HomeScreenCode.GDenemyObjects3= [];
gdjs.HomeScreenCode.GDplayObjects1= [];
gdjs.HomeScreenCode.GDplayObjects2= [];
gdjs.HomeScreenCode.GDplayObjects3= [];
gdjs.HomeScreenCode.GDcreditObjects1= [];
gdjs.HomeScreenCode.GDcreditObjects2= [];
gdjs.HomeScreenCode.GDcreditObjects3= [];
gdjs.HomeScreenCode.GDhtpObjects1= [];
gdjs.HomeScreenCode.GDhtpObjects2= [];
gdjs.HomeScreenCode.GDhtpObjects3= [];
gdjs.HomeScreenCode.GDInstaObjects1= [];
gdjs.HomeScreenCode.GDInstaObjects2= [];
gdjs.HomeScreenCode.GDInstaObjects3= [];
gdjs.HomeScreenCode.GDdiscordObjects1= [];
gdjs.HomeScreenCode.GDdiscordObjects2= [];
gdjs.HomeScreenCode.GDdiscordObjects3= [];
gdjs.HomeScreenCode.GDYoutubeObjects1= [];
gdjs.HomeScreenCode.GDYoutubeObjects2= [];
gdjs.HomeScreenCode.GDYoutubeObjects3= [];

gdjs.HomeScreenCode.conditionTrue_0 = {val:false};
gdjs.HomeScreenCode.condition0IsTrue_0 = {val:false};
gdjs.HomeScreenCode.condition1IsTrue_0 = {val:false};
gdjs.HomeScreenCode.condition2IsTrue_0 = {val:false};
gdjs.HomeScreenCode.condition3IsTrue_0 = {val:false};
gdjs.HomeScreenCode.conditionTrue_1 = {val:false};
gdjs.HomeScreenCode.condition0IsTrue_1 = {val:false};
gdjs.HomeScreenCode.condition1IsTrue_1 = {val:false};
gdjs.HomeScreenCode.condition2IsTrue_1 = {val:false};
gdjs.HomeScreenCode.condition3IsTrue_1 = {val:false};


gdjs.HomeScreenCode.mapOfGDgdjs_46HomeScreenCode_46GDplayObjects1Objects = Hashtable.newFrom({"play": gdjs.HomeScreenCode.GDplayObjects1});
gdjs.HomeScreenCode.mapOfGDgdjs_46HomeScreenCode_46GDhtpObjects1Objects = Hashtable.newFrom({"htp": gdjs.HomeScreenCode.GDhtpObjects1});
gdjs.HomeScreenCode.mapOfGDgdjs_46HomeScreenCode_46GDcreditObjects1Objects = Hashtable.newFrom({"credit": gdjs.HomeScreenCode.GDcreditObjects1});
gdjs.HomeScreenCode.mapOfGDgdjs_46HomeScreenCode_46GDInstaObjects1Objects = Hashtable.newFrom({"Insta": gdjs.HomeScreenCode.GDInstaObjects1});
gdjs.HomeScreenCode.mapOfGDgdjs_46HomeScreenCode_46GDYoutubeObjects1Objects = Hashtable.newFrom({"Youtube": gdjs.HomeScreenCode.GDYoutubeObjects1});
gdjs.HomeScreenCode.asyncCallback16163844 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Guide23"), gdjs.HomeScreenCode.GDGuide23Objects3);
{for(var i = 0, len = gdjs.HomeScreenCode.GDGuide23Objects3.length ;i < len;++i) {
    gdjs.HomeScreenCode.GDGuide23Objects3[i].getBehavior("Tween").addObjectPositionYTween("", 150, "bouncePast", 300, false);
}
}}
gdjs.HomeScreenCode.eventsList0 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.3), (runtimeScene) => (gdjs.HomeScreenCode.asyncCallback16163844(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.HomeScreenCode.asyncCallback16163388 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Guide2"), gdjs.HomeScreenCode.GDGuide2Objects2);
{for(var i = 0, len = gdjs.HomeScreenCode.GDGuide2Objects2.length ;i < len;++i) {
    gdjs.HomeScreenCode.GDGuide2Objects2[i].getBehavior("Tween").addObjectPositionYTween("", 43, "bouncePast", 300, false);
}
}
{ //Subevents
gdjs.HomeScreenCode.eventsList0(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.HomeScreenCode.eventsList1 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.3), (runtimeScene) => (gdjs.HomeScreenCode.asyncCallback16163388(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.HomeScreenCode.eventsList2 = function(runtimeScene) {

{


gdjs.HomeScreenCode.condition0IsTrue_0.val = false;
{
gdjs.HomeScreenCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.HomeScreenCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.preloadMusic(runtimeScene, "..\\assets\\game music\\MenuMusic.wav");
}{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "..\\assets\\game music\\MenuMusic.wav", 0, true, 150, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("play"), gdjs.HomeScreenCode.GDplayObjects1);

gdjs.HomeScreenCode.condition0IsTrue_0.val = false;
gdjs.HomeScreenCode.condition1IsTrue_0.val = false;
gdjs.HomeScreenCode.condition2IsTrue_0.val = false;
{
gdjs.HomeScreenCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.HomeScreenCode.mapOfGDgdjs_46HomeScreenCode_46GDplayObjects1Objects, runtimeScene, true, false);
}if ( gdjs.HomeScreenCode.condition0IsTrue_0.val ) {
{
gdjs.HomeScreenCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.HomeScreenCode.condition1IsTrue_0.val ) {
{
{gdjs.HomeScreenCode.conditionTrue_1 = gdjs.HomeScreenCode.condition2IsTrue_0;
gdjs.HomeScreenCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13531444);
}
}}
}
if (gdjs.HomeScreenCode.condition2IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Main", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("htp"), gdjs.HomeScreenCode.GDhtpObjects1);

gdjs.HomeScreenCode.condition0IsTrue_0.val = false;
gdjs.HomeScreenCode.condition1IsTrue_0.val = false;
gdjs.HomeScreenCode.condition2IsTrue_0.val = false;
{
gdjs.HomeScreenCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.HomeScreenCode.mapOfGDgdjs_46HomeScreenCode_46GDhtpObjects1Objects, runtimeScene, true, false);
}if ( gdjs.HomeScreenCode.condition0IsTrue_0.val ) {
{
gdjs.HomeScreenCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.HomeScreenCode.condition1IsTrue_0.val ) {
{
{gdjs.HomeScreenCode.conditionTrue_1 = gdjs.HomeScreenCode.condition2IsTrue_0;
gdjs.HomeScreenCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11157900);
}
}}
}
if (gdjs.HomeScreenCode.condition2IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "HowToPlay", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("credit"), gdjs.HomeScreenCode.GDcreditObjects1);

gdjs.HomeScreenCode.condition0IsTrue_0.val = false;
gdjs.HomeScreenCode.condition1IsTrue_0.val = false;
gdjs.HomeScreenCode.condition2IsTrue_0.val = false;
{
gdjs.HomeScreenCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.HomeScreenCode.mapOfGDgdjs_46HomeScreenCode_46GDcreditObjects1Objects, runtimeScene, true, false);
}if ( gdjs.HomeScreenCode.condition0IsTrue_0.val ) {
{
gdjs.HomeScreenCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.HomeScreenCode.condition1IsTrue_0.val ) {
{
{gdjs.HomeScreenCode.conditionTrue_1 = gdjs.HomeScreenCode.condition2IsTrue_0;
gdjs.HomeScreenCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(15968540);
}
}}
}
if (gdjs.HomeScreenCode.condition2IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Credit", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Insta"), gdjs.HomeScreenCode.GDInstaObjects1);

gdjs.HomeScreenCode.condition0IsTrue_0.val = false;
gdjs.HomeScreenCode.condition1IsTrue_0.val = false;
gdjs.HomeScreenCode.condition2IsTrue_0.val = false;
{
gdjs.HomeScreenCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.HomeScreenCode.mapOfGDgdjs_46HomeScreenCode_46GDInstaObjects1Objects, runtimeScene, true, false);
}if ( gdjs.HomeScreenCode.condition0IsTrue_0.val ) {
{
gdjs.HomeScreenCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.HomeScreenCode.condition1IsTrue_0.val ) {
{
{gdjs.HomeScreenCode.conditionTrue_1 = gdjs.HomeScreenCode.condition2IsTrue_0;
gdjs.HomeScreenCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13972932);
}
}}
}
if (gdjs.HomeScreenCode.condition2IsTrue_0.val) {
{gdjs.evtTools.window.openURL("https://www.instagram.com/ziox.indie_dev24/", runtimeScene);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Youtube"), gdjs.HomeScreenCode.GDYoutubeObjects1);

gdjs.HomeScreenCode.condition0IsTrue_0.val = false;
gdjs.HomeScreenCode.condition1IsTrue_0.val = false;
gdjs.HomeScreenCode.condition2IsTrue_0.val = false;
{
gdjs.HomeScreenCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.HomeScreenCode.mapOfGDgdjs_46HomeScreenCode_46GDYoutubeObjects1Objects, runtimeScene, true, false);
}if ( gdjs.HomeScreenCode.condition0IsTrue_0.val ) {
{
gdjs.HomeScreenCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.HomeScreenCode.condition1IsTrue_0.val ) {
{
{gdjs.HomeScreenCode.conditionTrue_1 = gdjs.HomeScreenCode.condition2IsTrue_0;
gdjs.HomeScreenCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11190596);
}
}}
}
if (gdjs.HomeScreenCode.condition2IsTrue_0.val) {
{gdjs.evtTools.window.openURL("https://www.youtube.com/channel/UCb0GH9HouZsU4EQI3vNJGeA", runtimeScene);
}}

}


{


gdjs.HomeScreenCode.condition0IsTrue_0.val = false;
{
gdjs.HomeScreenCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.HomeScreenCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.HomeScreenCode.eventsList1(runtimeScene);} //End of subevents
}

}


{


gdjs.HomeScreenCode.condition0IsTrue_0.val = false;
{
gdjs.HomeScreenCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.HomeScreenCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.preloadMusic(runtimeScene, "..\\assets\\game music\\GameMusic.wav");
}}

}


};

gdjs.HomeScreenCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.HomeScreenCode.GDplayerObjects1.length = 0;
gdjs.HomeScreenCode.GDplayerObjects2.length = 0;
gdjs.HomeScreenCode.GDplayerObjects3.length = 0;
gdjs.HomeScreenCode.GDGuide2Objects1.length = 0;
gdjs.HomeScreenCode.GDGuide2Objects2.length = 0;
gdjs.HomeScreenCode.GDGuide2Objects3.length = 0;
gdjs.HomeScreenCode.GDGuide22Objects1.length = 0;
gdjs.HomeScreenCode.GDGuide22Objects2.length = 0;
gdjs.HomeScreenCode.GDGuide22Objects3.length = 0;
gdjs.HomeScreenCode.GDGuide23Objects1.length = 0;
gdjs.HomeScreenCode.GDGuide23Objects2.length = 0;
gdjs.HomeScreenCode.GDGuide23Objects3.length = 0;
gdjs.HomeScreenCode.GDTitleObjects1.length = 0;
gdjs.HomeScreenCode.GDTitleObjects2.length = 0;
gdjs.HomeScreenCode.GDTitleObjects3.length = 0;
gdjs.HomeScreenCode.GDgrass1Objects1.length = 0;
gdjs.HomeScreenCode.GDgrass1Objects2.length = 0;
gdjs.HomeScreenCode.GDgrass1Objects3.length = 0;
gdjs.HomeScreenCode.GDgrass2Objects1.length = 0;
gdjs.HomeScreenCode.GDgrass2Objects2.length = 0;
gdjs.HomeScreenCode.GDgrass2Objects3.length = 0;
gdjs.HomeScreenCode.GDgrass3Objects1.length = 0;
gdjs.HomeScreenCode.GDgrass3Objects2.length = 0;
gdjs.HomeScreenCode.GDgrass3Objects3.length = 0;
gdjs.HomeScreenCode.GDgrass4Objects1.length = 0;
gdjs.HomeScreenCode.GDgrass4Objects2.length = 0;
gdjs.HomeScreenCode.GDgrass4Objects3.length = 0;
gdjs.HomeScreenCode.GDassetsObjects1.length = 0;
gdjs.HomeScreenCode.GDassetsObjects2.length = 0;
gdjs.HomeScreenCode.GDassetsObjects3.length = 0;
gdjs.HomeScreenCode.GDmusicObjects1.length = 0;
gdjs.HomeScreenCode.GDmusicObjects2.length = 0;
gdjs.HomeScreenCode.GDmusicObjects3.length = 0;
gdjs.HomeScreenCode.GDmusic2Objects1.length = 0;
gdjs.HomeScreenCode.GDmusic2Objects2.length = 0;
gdjs.HomeScreenCode.GDmusic2Objects3.length = 0;
gdjs.HomeScreenCode.GDboneObjects1.length = 0;
gdjs.HomeScreenCode.GDboneObjects2.length = 0;
gdjs.HomeScreenCode.GDboneObjects3.length = 0;
gdjs.HomeScreenCode.GDskullObjects1.length = 0;
gdjs.HomeScreenCode.GDskullObjects2.length = 0;
gdjs.HomeScreenCode.GDskullObjects3.length = 0;
gdjs.HomeScreenCode.GDenemyObjects1.length = 0;
gdjs.HomeScreenCode.GDenemyObjects2.length = 0;
gdjs.HomeScreenCode.GDenemyObjects3.length = 0;
gdjs.HomeScreenCode.GDplayObjects1.length = 0;
gdjs.HomeScreenCode.GDplayObjects2.length = 0;
gdjs.HomeScreenCode.GDplayObjects3.length = 0;
gdjs.HomeScreenCode.GDcreditObjects1.length = 0;
gdjs.HomeScreenCode.GDcreditObjects2.length = 0;
gdjs.HomeScreenCode.GDcreditObjects3.length = 0;
gdjs.HomeScreenCode.GDhtpObjects1.length = 0;
gdjs.HomeScreenCode.GDhtpObjects2.length = 0;
gdjs.HomeScreenCode.GDhtpObjects3.length = 0;
gdjs.HomeScreenCode.GDInstaObjects1.length = 0;
gdjs.HomeScreenCode.GDInstaObjects2.length = 0;
gdjs.HomeScreenCode.GDInstaObjects3.length = 0;
gdjs.HomeScreenCode.GDdiscordObjects1.length = 0;
gdjs.HomeScreenCode.GDdiscordObjects2.length = 0;
gdjs.HomeScreenCode.GDdiscordObjects3.length = 0;
gdjs.HomeScreenCode.GDYoutubeObjects1.length = 0;
gdjs.HomeScreenCode.GDYoutubeObjects2.length = 0;
gdjs.HomeScreenCode.GDYoutubeObjects3.length = 0;

gdjs.HomeScreenCode.eventsList2(runtimeScene);
return;

}

gdjs['HomeScreenCode'] = gdjs.HomeScreenCode;

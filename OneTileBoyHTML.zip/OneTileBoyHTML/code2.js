gdjs.HowToPlayCode = {};
gdjs.HowToPlayCode.GDplayerObjects1= [];
gdjs.HowToPlayCode.GDplayerObjects2= [];
gdjs.HowToPlayCode.GDGuide2Objects1= [];
gdjs.HowToPlayCode.GDGuide2Objects2= [];
gdjs.HowToPlayCode.GDGuide22Objects1= [];
gdjs.HowToPlayCode.GDGuide22Objects2= [];
gdjs.HowToPlayCode.GDGuide23Objects1= [];
gdjs.HowToPlayCode.GDGuide23Objects2= [];
gdjs.HowToPlayCode.GDTitleObjects1= [];
gdjs.HowToPlayCode.GDTitleObjects2= [];
gdjs.HowToPlayCode.GDgrass1Objects1= [];
gdjs.HowToPlayCode.GDgrass1Objects2= [];
gdjs.HowToPlayCode.GDgrass2Objects1= [];
gdjs.HowToPlayCode.GDgrass2Objects2= [];
gdjs.HowToPlayCode.GDgrass3Objects1= [];
gdjs.HowToPlayCode.GDgrass3Objects2= [];
gdjs.HowToPlayCode.GDgrass4Objects1= [];
gdjs.HowToPlayCode.GDgrass4Objects2= [];
gdjs.HowToPlayCode.GDassetsObjects1= [];
gdjs.HowToPlayCode.GDassetsObjects2= [];
gdjs.HowToPlayCode.GDmusicObjects1= [];
gdjs.HowToPlayCode.GDmusicObjects2= [];
gdjs.HowToPlayCode.GDmusic2Objects1= [];
gdjs.HowToPlayCode.GDmusic2Objects2= [];
gdjs.HowToPlayCode.GDboneObjects1= [];
gdjs.HowToPlayCode.GDboneObjects2= [];
gdjs.HowToPlayCode.GDskullObjects1= [];
gdjs.HowToPlayCode.GDskullObjects2= [];
gdjs.HowToPlayCode.GDhowtoplayObjects1= [];
gdjs.HowToPlayCode.GDhowtoplayObjects2= [];
gdjs.HowToPlayCode.GDescObjects1= [];
gdjs.HowToPlayCode.GDescObjects2= [];
gdjs.HowToPlayCode.GDtext1Objects1= [];
gdjs.HowToPlayCode.GDtext1Objects2= [];

gdjs.HowToPlayCode.conditionTrue_0 = {val:false};
gdjs.HowToPlayCode.condition0IsTrue_0 = {val:false};
gdjs.HowToPlayCode.condition1IsTrue_0 = {val:false};
gdjs.HowToPlayCode.condition2IsTrue_0 = {val:false};
gdjs.HowToPlayCode.conditionTrue_1 = {val:false};
gdjs.HowToPlayCode.condition0IsTrue_1 = {val:false};
gdjs.HowToPlayCode.condition1IsTrue_1 = {val:false};
gdjs.HowToPlayCode.condition2IsTrue_1 = {val:false};


gdjs.HowToPlayCode.eventsList0 = function(runtimeScene) {

{


gdjs.HowToPlayCode.condition0IsTrue_0.val = false;
gdjs.HowToPlayCode.condition1IsTrue_0.val = false;
{
gdjs.HowToPlayCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Tab");
}if ( gdjs.HowToPlayCode.condition0IsTrue_0.val ) {
{
{gdjs.HowToPlayCode.conditionTrue_1 = gdjs.HowToPlayCode.condition1IsTrue_0;
gdjs.HowToPlayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11180772);
}
}}
if (gdjs.HowToPlayCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "HomeScreen", false);
}}

}


};

gdjs.HowToPlayCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.HowToPlayCode.GDplayerObjects1.length = 0;
gdjs.HowToPlayCode.GDplayerObjects2.length = 0;
gdjs.HowToPlayCode.GDGuide2Objects1.length = 0;
gdjs.HowToPlayCode.GDGuide2Objects2.length = 0;
gdjs.HowToPlayCode.GDGuide22Objects1.length = 0;
gdjs.HowToPlayCode.GDGuide22Objects2.length = 0;
gdjs.HowToPlayCode.GDGuide23Objects1.length = 0;
gdjs.HowToPlayCode.GDGuide23Objects2.length = 0;
gdjs.HowToPlayCode.GDTitleObjects1.length = 0;
gdjs.HowToPlayCode.GDTitleObjects2.length = 0;
gdjs.HowToPlayCode.GDgrass1Objects1.length = 0;
gdjs.HowToPlayCode.GDgrass1Objects2.length = 0;
gdjs.HowToPlayCode.GDgrass2Objects1.length = 0;
gdjs.HowToPlayCode.GDgrass2Objects2.length = 0;
gdjs.HowToPlayCode.GDgrass3Objects1.length = 0;
gdjs.HowToPlayCode.GDgrass3Objects2.length = 0;
gdjs.HowToPlayCode.GDgrass4Objects1.length = 0;
gdjs.HowToPlayCode.GDgrass4Objects2.length = 0;
gdjs.HowToPlayCode.GDassetsObjects1.length = 0;
gdjs.HowToPlayCode.GDassetsObjects2.length = 0;
gdjs.HowToPlayCode.GDmusicObjects1.length = 0;
gdjs.HowToPlayCode.GDmusicObjects2.length = 0;
gdjs.HowToPlayCode.GDmusic2Objects1.length = 0;
gdjs.HowToPlayCode.GDmusic2Objects2.length = 0;
gdjs.HowToPlayCode.GDboneObjects1.length = 0;
gdjs.HowToPlayCode.GDboneObjects2.length = 0;
gdjs.HowToPlayCode.GDskullObjects1.length = 0;
gdjs.HowToPlayCode.GDskullObjects2.length = 0;
gdjs.HowToPlayCode.GDhowtoplayObjects1.length = 0;
gdjs.HowToPlayCode.GDhowtoplayObjects2.length = 0;
gdjs.HowToPlayCode.GDescObjects1.length = 0;
gdjs.HowToPlayCode.GDescObjects2.length = 0;
gdjs.HowToPlayCode.GDtext1Objects1.length = 0;
gdjs.HowToPlayCode.GDtext1Objects2.length = 0;

gdjs.HowToPlayCode.eventsList0(runtimeScene);
return;

}

gdjs['HowToPlayCode'] = gdjs.HowToPlayCode;
